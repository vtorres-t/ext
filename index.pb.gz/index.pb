
Keiyoushi-vtVT@DE0FDC4BC621BC9F68495CB030F4F23421D3257BA9A6DEBF3295C4076841C77B"<
https://keiyoushi.github.iohttps://discord.gg/3FbCpdKbdY�ϧ
�
AHottie)eu.kanade.tachiyomi.extension.all.ahottie�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.ahottie-v1.4.3.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ahottie.png"1.4(21.4.38B-�����WAHottieall"https://ahottie.top
�
Akuma'eu.kanade.tachiyomi.extension.all.akuma�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.akuma-v1.4.10.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.akuma.png"1.4(
21.4.108B)��������Akumaall"https://akuma.moeB(�����vAkumaen"https://akuma.moeB(�܊��JAkumaes"https://akuma.moe
�
AllPornComics.co1eu.kanade.tachiyomi.extension.all.allporncomicsco�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.allporncomicsco-v1.4.51.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.allporncomicsco.png"1.4(321.4.518B;�����˨�XAllPornComics.coall"https://allporncomics.co
�
	AsmHentai+eu.kanade.tachiyomi.extension.all.asmhentai�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.asmhentai-v1.4.11.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.asmhentai.png"1.4(21.4.118B0�ڌ��˫�U	AsmHentaien"https://asmhentai.comB1��֍��Ӈl	AsmHentaiall"https://asmhentai.com
�
BaoBua(eu.kanade.tachiyomi.extension.all.baobua�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.baobua-v1.4.6.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.baobua.png"1.4(21.4.68B+��ܰ�BaoBuaall"https://baobua.net
�
3600000 Beauty/eu.kanade.tachiyomi.extension.all.beauty3600000�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.beauty3600000-v1.4.6.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.beauty3600000.png"1.4(21.4.68B4������ɦL3600000 Beautyall"https://3600000.xyz
�
Buon Dua)eu.kanade.tachiyomi.extension.all.buondua�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.buondua-v1.4.10.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.buondua.png"1.4(
21.4.108B.�����Ҡ�Buon Duaall"https://buondua.com
�

Comic Fury+eu.kanade.tachiyomi.extension.all.comicfury�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.comicfury-v1.4.8.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicfury.png"1.4(21.4.88B2�脲���G
Comic Furyall"https://comicfury.comB1�ɾӧ���V
Comic Furyen"https://comicfury.comB1����ྖE
Comic Furyes"https://comicfury.comB4�͍��̲�
Comic Furyother"https://comicfury.comB>�������#Comic Fury (No Text)other"https://comicfury.com
�
Comic Growl,eu.kanade.tachiyomi.extension.all.comicgrowl�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.comicgrowl-v1.4.11.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicgrowl.png"1.4(21.4.11B5�������Comic Growlall"https://comic-growl.com
�
Comick (Unoriginal),eu.kanade.tachiyomi.extension.all.comicklive�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.comicklive-v1.4.5.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicklive.png"1.4(21.4.58B8�����ځEComick (Unoriginal)en"https://comick.liveB8���Ɵ���=Comick (Unoriginal)es"https://comick.live
�
ComicsKingdom/eu.kanade.tachiyomi.extension.all.comicskingdom�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.comicskingdom-v1.4.3.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicskingdom.png"1.4(21.4.3B<���Ӹ���.Comics Kingdomen"https://wp.comicskingdom.comB<����π��YComics Kingdomes"https://wp.comicskingdom.com
�
Comics Valley.eu.kanade.tachiyomi.extension.all.comicsvalley�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.comicsvalley-v1.4.53.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comicsvalley.png"1.4(521.4.538B8�Ӫ���קComics Valleyall"https://comicsvalley.com
�
Comikey)eu.kanade.tachiyomi.extension.all.comikey�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.comikey-v1.4.7.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.comikey.png"1.4(21.4.7B,ͼ���֠�&Comikeyen"https://comikey.comB,ſ������Comikeyes"https://comikey.comB,�嗗����Comikeyid"https://comikey.comB/�������9Comikeypt-BR"https://comikey.comB9�����DComikey Brasilpt-BR"https://br.comikey.com
�
Commit Strip-eu.kanade.tachiyomi.extension.all.commitstrip�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.commitstrip-v1.4.4.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.commitstrip.png"1.4(21.4.4B9Ԓ������ICommit Stripen"https://www.commitstrip.comB9��ܠ�Ў:Commit Stripfr"https://www.commitstrip.com
�
Coomer(eu.kanade.tachiyomi.extension.all.coomer�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.coomer-v1.4.24.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.coomer.png"1.4(21.4.248B*�ƽ�����xCoomerall"https://coomer.st
�
	Corona EX*eu.kanade.tachiyomi.extension.all.coronaex�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.coronaex-v1.4.1.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.coronaex.png"1.4(21.4.1B3����ԌňB	Corona EXja"https://to-corona-ex.comB6��媩��w	Corona EXen"https://en.to-corona-ex.com
�
CosplayTele-eu.kanade.tachiyomi.extension.all.cosplaytele�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.cosplaytele-v1.4.5.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.cosplaytele.png"1.4(21.4.58B5���Ǿ�fCosplayTeleall"https://cosplaytele.com
�
Cubari(eu.kanade.tachiyomi.extension.all.cubari�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.cubari-v1.4.26.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.cubari.png"1.4(21.4.26B*Ց�ݘ���WCubarien"https://cubari.moeB+��ಓ��Cubariall"https://cubari.moeB-�͙�в��Cubariother"https://cubari.moe
�
Danbooru*eu.kanade.tachiyomi.extension.all.danbooru�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.danbooru-v1.4.3.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.danbooru.png"1.4(21.4.38B5��������iDanbooruall"https://danbooru.donmai.us
�

DeviantArt,eu.kanade.tachiyomi.extension.all.deviantart�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.deviantart-v1.4.10.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.deviantart.png"1.4(
21.4.108B7΋�̿���H
DeviantArtall"https://www.deviantart.com
�
Dragon Ball Multiverse6eu.kanade.tachiyomi.extension.all.dragonballmultiverse�
qhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.dragonballmultiverse-v1.4.8.apkhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.dragonballmultiverse.png"1.4(21.4.8BM����آРQDragon Ball Multiverseen"%https://www.dragonball-multiverse.comBM��������&Dragon Ball Multiversees"%https://www.dragonball-multiverse.comBQ�ؔ�����9Dragon Ball Multiversees-419"%https://www.dragonball-multiverse.com
�
e621&eu.kanade.tachiyomi.extension.all.e621�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.e621-v1.4.2.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.e621.png"1.4(21.4.28B'�嶱����1e621all"https://e621.net
�
Elite Babes,eu.kanade.tachiyomi.extension.all.elitebabes�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.elitebabes-v1.4.2.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.elitebabes.png"1.4(21.4.28B8������^Elite Babesall"https://www.elitebabes.com
�
Everia.club,eu.kanade.tachiyomi.extension.all.everiaclub�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.everiaclub-v1.4.12.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.everiaclub.png"1.4(21.4.128B1����ծ��jEveria.cluball"https://everia.club
�
EveriaClub (unoriginal)/eu.kanade.tachiyomi.extension.all.everiaclubcom�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.everiaclubcom-v1.4.1.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.everiaclubcom.png"1.4(21.4.18BD���ج���xEveriaClub (unoriginal)all"https://www.everiaclub.com
�
Femjoy Hunter.eu.kanade.tachiyomi.extension.all.femjoyhunter�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.femjoyhunter-v1.4.2.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.femjoyhunter.png"1.4(21.4.28B<ё�����Femjoy Hunterall"https://www.femjoyhunter.com
�
FoamGirl*eu.kanade.tachiyomi.extension.all.foamgirl�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.foamgirl-v1.4.5.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.foamgirl.png"1.4(21.4.58B/����켸�QFoamGirlall"https://foamgirl.net
�
FoolSlide Customizable7eu.kanade.tachiyomi.extension.all.foolslidecustomizable�
rhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.foolslidecustomizable-v1.4.5.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.foolslidecustomizable.png"1.4(21.4.5B<������ޑXFoolSlide Customizableother"https://127.0.0.1
�
4KHD)eu.kanade.tachiyomi.extension.all.fourkhd�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.fourkhd-v1.4.2.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.fourkhd.png"1.4(21.4.28B+�ϑ�����Z4KHDall"https://www.4khd.com
�

FTV Hunter+eu.kanade.tachiyomi.extension.all.ftvhunter�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.ftvhunter-v1.4.2.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ftvhunter.png"1.4(21.4.28B6֌������!
FTV Hunterall"https://www.ftvhunter.com
�
GlobalComix-eu.kanade.tachiyomi.extension.all.globalcomix�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.globalcomix-v1.4.4.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.globalcomix.png"1.4(21.4.48B4���Е���GlobalComixen"https://globalcomix.comB4���뷻��CGlobalComixes"https://globalcomix.com
�
Grabber Zone-eu.kanade.tachiyomi.extension.all.grabberzone�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.grabberzone-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.grabberzone.png"1.4(321.4.51B3ɹ��칤�aGrabber Zoneall"https://grabber.zone
�
HDoujin)eu.kanade.tachiyomi.extension.all.hdoujin�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.hdoujin-v1.4.4.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hdoujin.png"1.4(21.4.48B-Λ��ݦ��HDoujinall"https://hdoujin.orgB,��ѡ���3HDoujinen"https://hdoujin.orgB,ǁ������[HDoujines"https://hdoujin.org
�
Hennojin*eu.kanade.tachiyomi.extension.all.hennojin�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.hennojin-v1.4.3.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hennojin.png"1.4(21.4.38B.�у�����"Hennojinen"https://hennojin.comB.��������]Hennojinja"https://hennojin.com
�
3Hentai)eu.kanade.tachiyomi.extension.all.hentai3�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.hentai3-v1.4.3.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentai3.png"1.4(21.4.38B-�����͞�_3Hentaiall"https://3hentai.netB,�ܭ⋊��l3Hentaien"https://3hentai.netB,�������3Hentaies"https://3hentai.net
�
Hentai Cosplay/eu.kanade.tachiyomi.extension.all.hentaicosplay�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.hentaicosplay-v1.4.8.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaicosplay.png"1.4(21.4.88B?Ŝ��֋¿/Hentai Cosplayall"https://hentai-cosplay-xxx.com
�

HentaiEnvy,eu.kanade.tachiyomi.extension.all.hentaienvy�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.hentaienvy-v1.4.9.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaienvy.png"1.4(	21.4.98B2�掕��݄p
HentaiEnvyen"https://hentaienvy.comB2��ߔ�̍�n
HentaiEnvyja"https://hentaienvy.comB2��ڎ���
HentaiEnvyes"https://hentaienvy.comB2��������
HentaiEnvyfr"https://hentaienvy.comB2�����Ǐ�$
HentaiEnvyko"https://hentaienvy.comB2��Ϭ�"
HentaiEnvyde"https://hentaienvy.comB2���袃�\
HentaiEnvyru"https://hentaienvy.comB3��������
HentaiEnvyall"https://hentaienvy.com
�
	HentaiEra+eu.kanade.tachiyomi.extension.all.hentaiera�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.hentaiera-v1.4.11.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaiera.png"1.4(21.4.118B0�����ҷ�	HentaiEraen"https://hentaiera.comB0������"	HentaiEraja"https://hentaiera.comB0͵��̛��	HentaiEraes"https://hentaiera.comB0��ݬ���_	HentaiErafr"https://hentaiera.comB0��������R	HentaiErako"https://hentaiera.comB0���؜���	HentaiErade"https://hentaiera.comB0�ݏ�����D	HentaiEraru"https://hentaiera.comB1�������H	HentaiEraall"https://hentaiera.com
�
	HentaiFox+eu.kanade.tachiyomi.extension.all.hentaifox�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.hentaifox-v1.4.16.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaifox.png"1.4(21.4.168B0䃇��ɛ�n	HentaiFoxen"https://hentaifox.comB1���䖦�%	HentaiFoxall"https://hentaifox.com
�

HentaiHand,eu.kanade.tachiyomi.extension.all.hentaihand�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.hentaihand-v1.4.10.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaihand.png"1.4(
21.4.108B3�������
HentaiHandall"https://hentaihand.comB2����֡��
HentaiHanden"https://hentaihand.comB2��������
HentaiHandes"https://hentaihand.com
�
	HentaiRox+eu.kanade.tachiyomi.extension.all.hentairox�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.hentairox-v1.4.9.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentairox.png"1.4(	21.4.98B0ʕ������&	HentaiRoxen"https://hentairox.comB1��ĕ����-	HentaiRoxall"https://hentairox.com
�
	HentaiZap+eu.kanade.tachiyomi.extension.all.hentaizap�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.hentaizap-v1.4.9.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hentaizap.png"1.4(	21.4.98B0➞����*	HentaiZapen"https://hentaizap.comB0������Z	HentaiZapja"https://hentaizap.comB0��������B	HentaiZapes"https://hentaizap.comB0��������m	HentaiZapfr"https://hentaizap.comB0��������	HentaiZapko"https://hentaizap.comB0�ϯ��Ԉ�	HentaiZapde"https://hentaizap.comB0���٘���[	HentaiZapru"https://hentaizap.comB1�І�����	HentaiZapall"https://hentaizap.com
�
HNI-Scantrad-eu.kanade.tachiyomi.extension.all.hniscantrad�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.hniscantrad-v1.4.9.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.hniscantrad.png"1.4(	21.4.9B7��������EHNI-Scantradall"https://hni-scantrad.net
�
HOLONOMETRIA.eu.kanade.tachiyomi.extension.all.holonometria�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.holonometria-v1.4.4.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.holonometria.png"1.4(21.4.4B3�茿���yHOLONOMETRIAja"https://holoearth.comB3��������HOLONOMETRIAen"https://holoearth.comB3��ƀ΍��FHOLONOMETRIAid"https://holoearth.com
�
	Honeytoon+eu.kanade.tachiyomi.extension.all.honeytoon�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.honeytoon-v1.4.2.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.honeytoon.png"1.4(21.4.28B0�����җ�w	Honeytoonde"https://honeytoon.comB0�������	Honeytoonen"https://honeytoon.comB0�������L	Honeytoones"https://honeytoon.comB0�ʭ��ܟ�[	Honeytoonfr"https://honeytoon.comB0��������}	Honeytoonit"https://honeytoon.comB3�ݠ�����g	Honeytoonpt-BR"https://honeytoon.com
�
IMHentai*eu.kanade.tachiyomi.extension.all.imhentai�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.imhentai-v1.4.24.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.imhentai.png"1.4(21.4.248B.�������IMHentaien"https://imhentai.xxxB.��롈���'IMHentaija"https://imhentai.xxxB.�ŀ����IMHentaies"https://imhentai.xxxB.���̻ZIMHentaifr"https://imhentai.xxxB.ؽ�ڧ�ԜIMHentaiko"https://imhentai.xxxB.�る����IMHentaide"https://imhentai.xxxB.������єhIMHentairu"https://imhentai.xxxB/������Ə/IMHentaiall"https://imhentai.xxx
�
izneo (webtoons)'eu.kanade.tachiyomi.extension.all.izneo�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.izneo-v1.4.8.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.izneo.png"1.4(21.4.8B7ÿ���꠰cizneoen" https://www.izneo.com/en/webtoonB7������izneofr" https://www.izneo.com/fr/webtoon
�
JJCOS'eu.kanade.tachiyomi.extension.all.jjcos�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.jjcos-v1.4.1.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.jjcos.png"1.4(21.4.18B)�����OJJCOSall"https://jjcos.com
�

Joymii Hub+eu.kanade.tachiyomi.extension.all.joymiihub�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.joymiihub-v1.4.2.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.joymiihub.png"1.4(21.4.28B6���濲��t
Joymii Huball"https://www.joymiihub.com
�
Junmeitu*eu.kanade.tachiyomi.extension.all.junmeitu�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.junmeitu-v1.4.7.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.junmeitu.png"1.4(21.4.78B/쒍�����AJunmeituall"https://meijuntu.com
�
Kagane(eu.kanade.tachiyomi.extension.all.kagane�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.kagane-v1.4.26.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kagane.png"1.4(21.4.268B)�չ����7Kaganeen"https://kagane.toB)�������WKaganees"https://kagane.toB-������׋-Kaganees-419"https://kagane.to
�
Kemono(eu.kanade.tachiyomi.extension.all.kemono�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.kemono-v1.4.25.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kemono.png"1.4(21.4.258B*��������Kemonoall"https://kemono.cr
�
Kiutaku)eu.kanade.tachiyomi.extension.all.kiutaku�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.kiutaku-v1.4.6.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kiutaku.png"1.4(21.4.68B-�Щ�����*Kiutakuall"https://kiutaku.com
�
Kodoku Studio.eu.kanade.tachiyomi.extension.all.kodokustudio�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.kodokustudio-v1.4.51.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.kodokustudio.png"1.4(321.4.51B8�����Kodoku Studioall"https://kodokustudio.com
�
SchaleNetwork(eu.kanade.tachiyomi.extension.all.koharu�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.koharu-v1.4.20.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.koharu.png"1.4(21.4.208B6�����ߏ�	SchaleNetworkall"https://schale.networkB5���͉���SchaleNetworken"https://schale.network
�
Komga'eu.kanade.tachiyomi.extension.all.komga�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.komga-v1.4.65.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.komga.png"1.4(A21.4.65BЧ����>KomgaallB����Ǻ��p	Komga (2)allB��ۖ��ڝG	Komga (3)all
�
	LANraragi+eu.kanade.tachiyomi.extension.all.lanraragi�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.lanraragi-v1.4.21.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.lanraragi.png"1.4(21.4.21B5����惾�>LANraragi (1)all"http://127.0.0.1:3000B5�����ә�ULANraragi (2)all"http://127.0.0.1:3000
�
League of Legends1eu.kanade.tachiyomi.extension.all.leagueoflegends�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.leagueoflegends-v1.4.2.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.leagueoflegends.png"1.4(21.4.2BTَ���駞KLeague of Legendsen"1https://universe.leagueoflegends.com/en_us/comic/BT��������"League of Legendses"1https://universe.leagueoflegends.com/es_es/comic/BX��������,League of Legendses-419"1https://universe.leagueoflegends.com/es_mx/comic/
�
Lunar Manga,eu.kanade.tachiyomi.extension.all.lunaranime�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.lunaranime-v1.4.8.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.lunaranime.png"1.4(21.4.88B3��������PLunar Mangaall"https://lunaranime.ruB2�������eLunar Mangaen"https://lunaranime.ruB2��«椥�Lunar Mangaes"https://lunaranime.ruB6�ێ�����?Lunar Mangaes-419"https://lunaranime.ru
�
Luscious*eu.kanade.tachiyomi.extension.all.luscious�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.luscious-v1.4.32.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.luscious.png"1.4( 21.4.328B2��Ϲ濨�&Lusciousen"https://www.luscious.netB2ۥ����;Lusciouses"https://www.luscious.netB5򼡄̓ÙLusciousother"https://www.luscious.netB3����ߛ�@Lusciousall"https://www.luscious.net
�
Magical Translators4eu.kanade.tachiyomi.extension.all.magicaltranslators�
ohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.magicaltranslators-v1.4.8.apk}https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.magicaltranslators.png"1.4(21.4.8B>�ë҃���7Magical Translatorsen"https://mahoushoujobu.comB>���쭪ţxMagical Translatorses"https://mahoushoujobu.comB>��������Magical Translatorspl"https://mahoushoujobu.com
�
	Manga18Me+eu.kanade.tachiyomi.extension.all.manga18me�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.manga18me-v1.4.3.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manga18me.png"1.4(21.4.38B/���ĺ��
Manga18.meall"https://manga18.meB.��ԛ����V
Manga18.meen"https://manga18.me
�

Manga Ball+eu.kanade.tachiyomi.extension.all.mangaball�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangaball-v1.4.3.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaball.png"1.4(21.4.38B1�������
Manga Ballen"https://mangaball.netB1���Ԉ�
Manga Balles"https://mangaball.net
�

MangaCrazy,eu.kanade.tachiyomi.extension.all.mangacrazy�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangacrazy-v1.4.51.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangacrazy.png"1.4(321.4.518B3�Ϧ�����^
MangaCrazyall"https://mangacrazy.net
�
MangaDex*eu.kanade.tachiyomi.extension.all.mangadex�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangadex-v1.4.210.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangadex.png"1.4(�21.4.2108B.���ׯ���"MangaDexen"https://mangadex.orgB2�͎�����DMangaDexes-419"https://mangadex.orgB.��乔���XMangaDexes"https://mangadex.org
�
MangaDNA*eu.kanade.tachiyomi.extension.all.mangadna�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangadna-v1.4.2.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangadna.png"1.4(21.4.28B.�������GMangaDNAen"https://mangadna.comB/��������VMangaDNAall"https://mangadna.com
�
Manga Draft,eu.kanade.tachiyomi.extension.all.mangadraft�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangadraft-v1.4.1.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangadraft.png"1.4(21.4.1B3��ϳ�ń�_
MangaDraftall"https://mangadraft.com
�
	MangaFire+eu.kanade.tachiyomi.extension.all.mangafire�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangafire-v1.4.24.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangafire.png"1.4(21.4.248B/�������T	MangaFireen"https://mangafire.toB/��ç���p	MangaFirees"https://mangafire.toB3��˽��5	MangaFirees-419"https://mangafire.toB/����֞��V	MangaFirefr"https://mangafire.toB/����׃��	MangaFireja"https://mangafire.toB/ۄ�ʾ���
	MangaFirept"https://mangafire.toB2�����ȷ�l	MangaFirept-BR"https://mangafire.to
�
MangaForFree.net.eu.kanade.tachiyomi.extension.all.mangaforfree�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangaforfree-v1.4.53.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaforfree.png"1.4(521.4.538B:�ӏ��Ѷ�gMangaForFree.neten"https://mangaforfree.netB:�ϗր�ѭMangaForFree.netko"https://mangaforfree.netB:�������MangaForFree.netall"https://mangaforfree.net
�
MANGA Plus by SHUEISHA+eu.kanade.tachiyomi.extension.all.mangaplus�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangaplus-v1.4.62.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaplus.png"1.4(>21.4.62BH��������MANGA Plus by SHUEISHAen" https://mangaplus.shueisha.co.jpBHΦ��ڙ��MANGA Plus by SHUEISHAes" https://mangaplus.shueisha.co.jpBH�ـ�����jMANGA Plus by SHUEISHAfr" https://mangaplus.shueisha.co.jpBH﷯����MANGA Plus by SHUEISHAid" https://mangaplus.shueisha.co.jpBK�������/MANGA Plus by SHUEISHApt-BR" https://mangaplus.shueisha.co.jpBH��ć���0MANGA Plus by SHUEISHAru" https://mangaplus.shueisha.co.jpBH����ߓ��XMANGA Plus by SHUEISHAth" https://mangaplus.shueisha.co.jpBH������AMANGA Plus by SHUEISHAvi" https://mangaplus.shueisha.co.jpBH�����ǣMANGA Plus by SHUEISHAde" https://mangaplus.shueisha.co.jp
�
MANGA Plus Creators by SHUEISHA3eu.kanade.tachiyomi.extension.all.mangapluscreators�
nhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangapluscreators-v1.4.3.apk|https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangapluscreators.png"1.4(21.4.3BN�Ѧ�Ť��EMANGA Plus Creators by SHUEISHAen"https://mangaplus-creators.jpBN��������MANGA Plus Creators by SHUEISHAes"https://mangaplus-creators.jp
�
	MangaTaro+eu.kanade.tachiyomi.extension.all.mangataro�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangataro-v1.4.11.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangataro.png"1.4(21.4.11B0��Ȥ����s	MangaTaroen"https://mangataro.orgB3֖������	MangaTaropt-BR"https://mangataro.org
�
MangaToon (Limited)+eu.kanade.tachiyomi.extension.all.mangatoon�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangatoon-v1.4.8.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangatoon.png"1.4(21.4.8B;�ڨ�����BMangaToon (Limited)en"https://mangatoon.mobiB;��웧羦MangaToon (Limited)es"https://mangatoon.mobi
�
	Manga UP!)eu.kanade.tachiyomi.extension.all.mangaup�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mangaup-v1.4.8.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mangaup.png"1.4(21.4.8B6��������j	Manga UP!en"https://global.manga-up.com
�
Mango'eu.kanade.tachiyomi.extension.all.mango�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mango-v1.4.11.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mango.png"1.4(21.4.11Bχ����(Mangoen
�
Manhuarm*eu.kanade.tachiyomi.extension.all.manhuarm�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.manhuarm-v1.4.76.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhuarm.png"1.4(L21.4.768B0竨ͣ���Manhuarmar"https://manhuarmtl.comB0�ç����jManhuarmen"https://manhuarmtl.comB0�������vManhuarmes"https://manhuarmtl.comB0����׍��vManhuarmfr"https://manhuarmtl.comB0������ݎYManhuarmid"https://manhuarmtl.comB0��˴ۣ�iManhuarmit"https://manhuarmtl.comB3�ܢ�����MManhuarmpt-BR"https://manhuarmtl.com
�
Manhwa18.cc,eu.kanade.tachiyomi.extension.all.manhwa18cc�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.manhwa18cc-v1.4.58.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwa18cc.png"1.4(:21.4.588B0������CManhwa18.ccen"https://manhwa18.ccB0߇������_Manhwa18.ccko"https://manhwa18.ccB1�������Manhwa18.ccall"https://manhwa18.cc
�
Manhwa18.net-eu.kanade.tachiyomi.extension.all.manhwa18net�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.manhwa18net-v1.4.13.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwa18net.png"1.4(21.4.138B2��������	Manhwa18.Neten"https://manhwa18.net
�
Manhwa 18 Uncensored4eu.kanade.tachiyomi.extension.all.manhwa18uncensored�
phttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.manhwa18uncensored-v1.4.51.apk}https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwa18uncensored.png"1.4(321.4.518BD��������xManhwa 18 Uncensoreden"https://manhwa18uncensored.comBE��ނ����Manhwa 18 Uncensoredall"https://manhwa18uncensored.com
�
ManhwaClub.net/eu.kanade.tachiyomi.extension.all.manhwaclubnet�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.manhwaclubnet-v1.4.51.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwaclubnet.png"1.4(321.4.518B6�ӧ�봫�]ManhwaClub.neten"https://manhwaclub.netB6��鄐�ʪ0ManhwaClub.netko"https://manhwaclub.net
�

Manhwa-raw/eu.kanade.tachiyomi.extension.all.manhwadashraw�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.manhwadashraw-v1.4.53.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manhwadashraw.png"1.4(521.4.538B3�����Ǩ�M
Manhwa-rawall"https://manhwa-raw.com
�
Manta Comics'eu.kanade.tachiyomi.extension.all.manta�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.manta-v1.4.9.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.manta.png"1.4(	21.4.98B+·˞��ϼyMantaen"https://manta.net/enB+�������'Mantaes"https://manta.net/es
�
MayoTune*eu.kanade.tachiyomi.extension.all.mayotune�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mayotune-v1.4.2.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mayotune.png"1.4(21.4.2B.��Ҝ����MayoTuneen"https://mayochuu.xyzB.��������\MayoTuneja"https://mayochuu.xyz
�
Metart Hunter.eu.kanade.tachiyomi.extension.all.metarthunter�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.metarthunter-v1.4.2.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.metarthunter.png"1.4(21.4.28B<��������1Metart Hunterall"https://www.metarthunter.com
�
	Miau Scan*eu.kanade.tachiyomi.extension.all.miauscan�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.miauscan-v1.4.39.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.miauscan.png"1.4('21.4.398B.�����Ɍ�(	Miau Scanes"https://leemiau.comB1�����ې�]	Miau Scanpt-BR"https://leemiau.com
�
MissKon)eu.kanade.tachiyomi.extension.all.misskon�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.misskon-v1.4.4.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.misskon.png"1.4(21.4.48B-��������MissKonall"https://misskon.com
�
Mitaku(eu.kanade.tachiyomi.extension.all.mitaku�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.mitaku-v1.4.4.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.mitaku.png"1.4(21.4.48B+֝������hMitakuall"https://mitaku.net
�
MyReadingManga0eu.kanade.tachiyomi.extension.all.myreadingmanga�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.myreadingmanga-v1.4.61.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.myreadingmanga.png"1.4(=21.4.618B;��ᛐ���WMyReadingMangaen"https://myreadingmanga.infoB;�筦Ќ��1MyReadingMangaes"https://myreadingmanga.info
�
NamiComi*eu.kanade.tachiyomi.extension.all.namicomi�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.namicomi-v1.4.6.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.namicomi.png"1.4(21.4.6B.Կ�����^NamiComien"https://namicomi.comB2��է���3NamiComies-419"https://namicomi.comB.��������gNamiComies"https://namicomi.com
�
nHentai.com (unoriginal),eu.kanade.tachiyomi.extension.all.nhentaicom�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.nhentaicom-v1.4.9.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.nhentaicom.png"1.4(	21.4.98B>�߯���nHentai.com (unoriginal)all"https://nhentai.comB=�����vnHentai.com (unoriginal)zh"https://nhentai.comB=��צ����MnHentai.com (unoriginal)en"https://nhentai.comB=�Ә�����qnHentai.com (unoriginal)ja"https://nhentai.comB@��������PnHentai.com (unoriginal)other"https://nhentai.comB=���ʧ���nHentai.com (unoriginal)ar"https://nhentai.comB=�������EnHentai.com (unoriginal)jv"https://nhentai.comB=׬��՞��JnHentai.com (unoriginal)bg"https://nhentai.comB=ĸ������nHentai.com (unoriginal)cs"https://nhentai.comB=���♗��nHentai.com (unoriginal)uk"https://nhentai.comB=��컸���qnHentai.com (unoriginal)sk"https://nhentai.comB=��환���KnHentai.com (unoriginal)eo"https://nhentai.comB=쏯�ß��2nHentai.com (unoriginal)mn"https://nhentai.comB=����ӄ��]nHentai.com (unoriginal)la"https://nhentai.comB>��͡��snHentai.com (unoriginal)ceb"https://nhentai.comB=ʥ���߹�<nHentai.com (unoriginal)tl"https://nhentai.comB=��ֱ����vnHentai.com (unoriginal)fi"https://nhentai.comB=�ӣ���͑YnHentai.com (unoriginal)tr"https://nhentai.comB=�喙����nHentai.com (unoriginal)sr"https://nhentai.comB=�������SnHentai.com (unoriginal)el"https://nhentai.comB=��������ZnHentai.com (unoriginal)ko"https://nhentai.comB=�ٮ�����rnHentai.com (unoriginal)ro"https://nhentai.com
�
NHentai.xxx,eu.kanade.tachiyomi.extension.all.nhentaixxx�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.nhentaixxx-v1.4.9.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.nhentaixxx.png"1.4(	21.4.98B0�����NHentai.xxxen"https://nhentai.xxxB1���ܗ�܋!NHentai.xxxall"https://nhentai.xxx
�
Niadd'eu.kanade.tachiyomi.extension.all.niadd�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.niadd-v1.4.2.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.niadd.png"1.4(21.4.28B.Т�����iNiaddpt-BR"https://br.niadd.comB,��������VNiadden"https://www.niadd.comB+ʙԝ�ǁNiaddes"https://es.niadd.comB+���䍖�rNiaddit"https://it.niadd.comB+�賃����Niaddru"https://ru.niadd.comB+㫞�����.Niaddde"https://de.niadd.comB+�ژ�����(Niaddfr"https://fr.niadd.com
�
	NovelCool+eu.kanade.tachiyomi.extension.all.novelcool�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.novelcool-v1.4.8.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.novelcool.png"1.4(21.4.88B4���Įᙇi	NovelCoolen"https://www.novelcool.comB3�є���׊	NovelCooles"https://es.novelcool.comB3��������B	NovelCoolde"https://de.novelcool.comB3��������	NovelCoolru"https://ru.novelcool.comB3��������	NovelCoolit"https://it.novelcool.comB6�������!	NovelCoolpt-BR"https://br.novelcool.comB3�􂋋��	NovelCoolfr"https://fr.novelcool.com
�
One Piece Fans.eu.kanade.tachiyomi.extension.all.onepiecefans�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.onepiecefans-v1.4.1.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.onepiecefans.png"1.4(21.4.1B;꯷�汩�)One Piece Fanses"https://one-piece-fans2.comB;��҄˒��[One Piece Fansen"https://one-piece-fans2.com
�
OniSaga)eu.kanade.tachiyomi.extension.all.onisaga�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.onisaga-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.onisaga.png"1.4(21.4.18B-����ϥ��wOniSagaall"https://onisaga.comB,���Ο���$OniSagaen"https://onisaga.comB,��𮈸��KOniSagafr"https://onisaga.comB,�����HOniSagaja"https://onisaga.comB/Փ���۞�JOniSagapt-BR"https://onisaga.comB,����Ѝ�4OniSagapt"https://onisaga.comB0؝ۙ����QOniSagaes-419"https://onisaga.comB,�����}OniSagaes"https://onisaga.com
�
OSOSEDKI*eu.kanade.tachiyomi.extension.all.ososedki�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.ososedki-v1.4.1.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.ososedki.png"1.4(21.4.18B/͎�ɖ���	OSOSEDKIall"https://ososedki.com
�
PandaChaika-eu.kanade.tachiyomi.extension.all.pandachaika�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.pandachaika-v1.4.4.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.pandachaika.png"1.4(21.4.48B6��ܵ����qPandaChaikaall"https://panda.chaika.moeB5��������1PandaChaikaen"https://panda.chaika.moeB5�����õ�PandaChaikaes"https://panda.chaika.moe
�
Pepper&Carrot.eu.kanade.tachiyomi.extension.all.peppercarrot�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.peppercarrot-v1.4.5.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.peppercarrot.png"1.4(21.4.5B<��Ĩ�Í�Pepper&Carrotall"https://www.peppercarrot.com
�
Photos18*eu.kanade.tachiyomi.extension.all.photos18�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.photos18-v1.4.6.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.photos18.png"1.4(21.4.68B3��������Photos18all"https://www.photos18.com
�
Pixiv'eu.kanade.tachiyomi.extension.all.pixiv�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.pixiv-v1.4.12.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.pixiv.png"1.4(21.4.128B,ކ���ŧ�DPixiven"https://www.pixiv.net
�
Playmate Hunter0eu.kanade.tachiyomi.extension.all.playmatehunter�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.playmatehunter-v1.4.2.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.playmatehunter.png"1.4(21.4.28B9ű���͐�Playmate Hunterall"https://pmatehunter.com
�
PornPics*eu.kanade.tachiyomi.extension.all.pornpics�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.pornpics-v1.4.3.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.pornpics.png"1.4(21.4.38B2��ȷ���PornPicsen"https://www.pornpics.com
�
Project Suki-eu.kanade.tachiyomi.extension.all.projectsuki�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.projectsuki-v1.4.8.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.projectsuki.png"1.4(21.4.8B7�����ն|Project Sukiall"https://projectsuki.com/
�

RokuHentai,eu.kanade.tachiyomi.extension.all.rokuhentai�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.rokuhentai-v1.4.1.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.rokuhentai.png"1.4(21.4.18B4�����ۀ^Roku Hentaiall"https://rokuhentai.com
�
BlossomManhwa.eu.kanade.tachiyomi.extension.all.sakuramanhwa�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.sakuramanhwa-v1.4.5.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.sakuramanhwa.png"1.4(21.4.58B<��ڄ���BlossomManhwaall"https://api.cherrymanhwa.com
�
Sandra and Woo.eu.kanade.tachiyomi.extension.all.sandraandwoo�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.sandraandwoo-v1.4.3.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.sandraandwoo.png"1.4(21.4.3B<�ո�����pSandra und Woode"https://www.sandraandwoo.comB<�������vSandra and Wooen"https://www.sandraandwoo.com
�
SeraphicDeviltry2eu.kanade.tachiyomi.extension.all.seraphicdeviltry�
nhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.seraphicdeviltry-v1.4.53.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.seraphicdeviltry.png"1.4(521.4.538B?Ҫ�����JSeraphicDeviltryen"https://seraphic-deviltry.comBG�����ӫ�[SeraphicDeviltryes"%https://spanish.seraphic-deviltry.com
�
Simply Cosplay/eu.kanade.tachiyomi.extension.all.simplycosplay�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.simplycosplay-v1.4.4.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.simplycosplay.png"1.4(21.4.48B?��������LSimply Cosplayall"https://www.simply-cosplay.com
�
Simply Hentai.eu.kanade.tachiyomi.extension.all.simplyhentai�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.simplyhentai-v1.4.8.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.simplyhentai.png"1.4(21.4.88B<׽���恓Simply Hentaien"https://www.simply-hentai.comB<ݪ���̔�	Simply Hentaies"https://www.simply-hentai.com
�
StashApp*eu.kanade.tachiyomi.extension.all.stashapp�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.stashapp-v1.4.1.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.stashapp.png"1.4(21.4.18B0������ߐ<StashAppall"http://localhost:9999
�
Taddy INK (Webtoons)*eu.kanade.tachiyomi.extension.all.taddyink�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.taddyink-v1.4.3.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.taddyink.png"1.4(21.4.3B8���Ӆ� Taddy INK (Webtoons)all"https://taddy.org
�
	Tappytoon+eu.kanade.tachiyomi.extension.all.tappytoon�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.tappytoon-v1.4.10.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.tappytoon.png"1.4(
21.4.108B7�������a	Tappytoonen"https://www.tappytoon.com/enB7������٫s	Tappytoonfr"https://www.tappytoon.com/frB7�ҵŎ���x	Tappytoonde"https://www.tappytoon.com/de
�
The Library of Ohara3eu.kanade.tachiyomi.extension.all.thelibraryofohara�
nhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.thelibraryofohara-v1.4.2.apk|https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.thelibraryofohara.png"1.4(21.4.2BC�É�����<The Library of Oharaid"https://thelibraryofohara.comBCɵ������%The Library of Oharaen"https://thelibraryofohara.comBC��ͨ��́The Library of Oharaes"https://thelibraryofohara.comBC��ϥ����The Library of Oharait"https://thelibraryofohara.comBC�߹�����qThe Library of Oharaar"https://thelibraryofohara.comBC����񉵘dThe Library of Oharafr"https://thelibraryofohara.com
�
Thunder Scans.eu.kanade.tachiyomi.extension.all.thunderscans�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.thunderscans-v1.4.44.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.thunderscans.png"1.4(,21.4.44B1��������,
Lava Scansar"https://lavascans.comB:܆Ζ����'Thunder Scansen"https://en-thunderscans.com
�
Toomics)eu.kanade.tachiyomi.extension.all.toomics�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.toomics-v1.4.10.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.toomics.png"1.4(
21.4.108BH������њaToomics (Only free chapters)en"https://global.toomics.comBM�㶘���Toomics (Only free chapters)zh-Hans"https://global.toomics.comBM��������Toomics (Only free chapters)zh-Hant"https://global.toomics.comBL����󊙖fToomics (Only free chapters)es-419"https://global.toomics.comBH�����ӿCToomics (Only free chapters)es"https://global.toomics.comBH�������jToomics (Only free chapters)it"https://global.toomics.comBHɣ�㑁��:Toomics (Only free chapters)de"https://global.toomics.comBH�����Toomics (Only free chapters)fr"https://global.toomics.comBK����麖�>Toomics (Only free chapters)pt-BR"https://global.toomics.com
�
Twicomi)eu.kanade.tachiyomi.extension.all.twicomi�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.twicomi-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.twicomi.png"1.4(21.4.18B-�������?Twicomiall"https://twicomi.com
�
Uncensored Manhwa2eu.kanade.tachiyomi.extension.all.uncensoredmanhwa�
nhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.uncensoredmanhwa-v1.4.51.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.uncensoredmanhwa.png"1.4(321.4.518B>󾜳�̠�Uncensored Manhwaen"https://uncensoredmanhwa.usB?�٥��Ш�rUncensored Manhwaall"https://uncensoredmanhwa.us
�
V2PH&eu.kanade.tachiyomi.extension.all.v2ph�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.v2ph-v1.4.1.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.v2ph.png"1.4(21.4.18B+γ������>V2PHall"https://www.v2ph.com
�
Vinne Veritas - CCC/eu.kanade.tachiyomi.extension.all.vinnieVeritas�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.vinnieVeritas-v1.4.3.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.vinnieVeritas.png"1.4(21.4.3BCު������|Vinnie Veritas - CCCen"https://ccc.vinnieveritas.comBC����ԟ�Vinnie Veritas - CCCes"https://ccc.vinnieveritas.com
�
Webtoons.com*eu.kanade.tachiyomi.extension.all.webtoons�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.webtoons-v1.4.55.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.webtoons.png"1.4(721.4.55B6ر����Ȁ#Webtoons.comen"https://www.webtoons.comB6ʮŮ�yWebtoons.comid"https://www.webtoons.comB6����ϔ�.Webtoons.comth"https://www.webtoons.comB6��҈��ԟxWebtoons.comes"https://www.webtoons.comB6��ҩ�͈�rWebtoons.comfr"https://www.webtoons.comB;��ӗ����)Webtoons.comzh-Hant"https://www.webtoons.comB6��������Webtoons.comde"https://www.webtoons.com
�
XArt Hunter,eu.kanade.tachiyomi.extension.all.xarthunter�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.xarthunter-v1.4.2.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xarthunter.png"1.4(21.4.28B8��џ�殆gXArt Hunterall"https://www.xarthunter.com
�
Xasiat Albums.eu.kanade.tachiyomi.extension.all.xasiatalbums�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.xasiatalbums-v1.4.3.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xasiatalbums.png"1.4(21.4.38B6�����cXAsiat Albumsall"https://www.xasiat.com
�
XGMN&eu.kanade.tachiyomi.extension.all.xgmn�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.xgmn-v1.4.3.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xgmn.png"1.4(21.4.38B/����Ǩ�'性感美女all"http://xgmn8.vip
�

Xinmeitulu,eu.kanade.tachiyomi.extension.all.xinmeitulu�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.xinmeitulu-v1.4.7.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xinmeitulu.png"1.4(21.4.78B7��к���i
Xinmeituluall"https://www.xinmeitulu.com
�
Xiutaku)eu.kanade.tachiyomi.extension.all.xiutaku�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.xiutaku-v1.4.4.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xiutaku.png"1.4(21.4.48B-���֝��ZXiutakuall"https://xiutaku.com
�
xkcd&eu.kanade.tachiyomi.extension.all.xkcd�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.xkcd-v1.4.16.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.xkcd.png"1.4(21.4.16B&��������xkcden"https://xkcd.comB)�����ʼ�_xkcdes"https://es.xkcd.com
�
Yabai'eu.kanade.tachiyomi.extension.all.yabai�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.yabai-v1.4.3.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yabai.png"1.4(21.4.38B(��͇����Yabaiall"https://yabai.si
�
Yaoi Manga Online1eu.kanade.tachiyomi.extension.all.yaoimangaonline�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.yaoimangaonline-v1.4.5.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yaoimangaonline.png"1.4(21.4.58B?������nYaoi Manga Onlineall"https://yaoimangaonline.com
�

YellowNote,eu.kanade.tachiyomi.extension.all.yellownote�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.yellownote-v1.4.6.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yellownote.png"1.4(21.4.68B0�è�����	小黄书all"https://en.xchina.co
�

YSK Comics+eu.kanade.tachiyomi.extension.all.yskcomics�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-all.yskcomics-v1.4.1.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.all.yskcomics.png"1.4(21.4.1B6������
YSK Comicsar"https://www.ysk-comics.comB6�ְч���
YSK Comicsen"https://www.ysk-comics.com
�

Akai Comic*eu.kanade.tachiyomi.extension.en.akaicomic�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.akaicomic-v1.4.3.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.akaicomic.png"1.4(21.4.3B1��ۖ���
Akai Comicen"https://akaicomic.org
�
Alandal(eu.kanade.tachiyomi.extension.en.alandal�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.alandal-v1.4.2.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.alandal.png"1.4(21.4.2B,��Ƈ�ɕ�Alandalen"https://alandal.com
�
AllManga)eu.kanade.tachiyomi.extension.en.allanime�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.allanime-v1.4.19.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.allanime.png"1.4(21.4.198B-��ظֹ��AAllMangaen"https://allmanga.to
�
AllPornComic-eu.kanade.tachiyomi.extension.en.allporncomic�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.allporncomic-v1.4.53.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.allporncomic.png"1.4(521.4.538B6��������vAllPornComicen"https://allporncomic.com
�
AllPornComic.io/eu.kanade.tachiyomi.extension.en.allporncomicio�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.allporncomicio-v1.4.51.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.allporncomicio.png"1.4(321.4.518B8�ѹ�����\AllPornComic.ioen"https://allporncomic.io
�
Anisa Scans+eu.kanade.tachiyomi.extension.en.anisascans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.anisascans-v1.4.52.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.anisascans.png"1.4(421.4.528B2Յ���Î�{Anisa Scansen"https://anisascans.in
�
	AP Comics)eu.kanade.tachiyomi.extension.en.apcomics�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.apcomics-v1.4.51.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.apcomics.png"1.4(321.4.518B/���ѵ���l	AP Comicsen"https://apcomics.org
�

Aqua Manga*eu.kanade.tachiyomi.extension.en.aquamanga�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.aquamanga-v1.4.62.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.aquamanga.png"1.4(>21.4.62B2������
Aqua Mangaen"https://aquareader.org
�
Arc-Relight+eu.kanade.tachiyomi.extension.en.arcrelight�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.arcrelight-v1.4.15.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.arcrelight.png"1.4(21.4.15B4�����ƙ�^Arc-Relighten"https://arc-relight.com
�
Arena Scans+eu.kanade.tachiyomi.extension.en.arenascans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.arenascans-v1.4.32.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.arenascans.png"1.4( 21.4.32B2����ٽ��zArena Scansen"https://arenascan.com
�

Armageddon+eu.kanade.tachiyomi.extension.en.armageddon�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.armageddon-v1.4.34.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.armageddon.png"1.4("21.4.348B7���Ꭹ��
Armageddonen"https://www.silentquill.net
�
	Art Lapsa)eu.kanade.tachiyomi.extension.en.artlapsa�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.artlapsa-v1.4.25.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.artlapsa.png"1.4(21.4.25B/�����Ș
	Art Lapsaen"https://artlapsa.com
�
Vortex Scans+eu.kanade.tachiyomi.extension.en.arvenscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.arvenscans-v1.4.61.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.arvenscans.png"1.4(=21.4.61B5��������#Vortex Scansen"https://vortexscans.org
�

Arya Scans*eu.kanade.tachiyomi.extension.en.aryascans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.aryascans-v1.4.52.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.aryascans.png"1.4(421.4.52B6˲������i
Arya Scansen"https://brainrotcomics.com
�
AsiaToon)eu.kanade.tachiyomi.extension.en.asiatoon�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.asiatoon-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.asiatoon.png"1.4(21.4.18B.��ݬ��vAsiaToonen"https://asiatoon.net
�
Asmodeus Scans)eu.kanade.tachiyomi.extension.en.asmotoon�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.asmotoon-v1.4.22.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.asmotoon.png"1.4(21.4.22B4����ж��HAsmodeus Scansen"https://asmotoon.com
�
Assorted Scans.eu.kanade.tachiyomi.extension.en.assortedscans�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.assortedscans-v1.4.17.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.assortedscans.png"1.4(21.4.17B9��������pAssorted Scansen"https://assortedscans.com
�
Asura Scans+eu.kanade.tachiyomi.extension.en.asurascans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.asurascans-v1.4.62.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.asurascans.png"1.4(>21.4.62B3�������VAsura Scansen"https://asurascans.com
�
Athrea Scans,eu.kanade.tachiyomi.extension.en.athreascans�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.athreascans-v1.4.33.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.athreascans.png"1.4(!21.4.338B5�㠏����Athrea Scansen"https://athreascans.com
�
Atsumaru)eu.kanade.tachiyomi.extension.en.atsumaru�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.atsumaru-v1.4.19.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.atsumaru.png"1.4(21.4.198B*�à�� Atsumaruen"https://atsu.moe
�
aurora'eu.kanade.tachiyomi.extension.en.aurora�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.aurora-v1.4.4.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.aurora.png"1.4(21.4.4B/��ܤӚ��~Auroraen"https://comicaurora.com
�
Omoi&eu.kanade.tachiyomi.extension.en.azuki�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.azuki-v1.4.2.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.azuki.png"1.4(21.4.28B*��¼���qOmoien"https://www.omoi.com
�
Bakkin'eu.kanade.tachiyomi.extension.en.bakkin�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.bakkin-v1.4.7.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bakkin.png"1.4(21.4.7B2ߵ�߷���Bakkinen"https://bakkin.moe/reader/
�
Bakkin Self-hosted1eu.kanade.tachiyomi.extension.en.bakkinselfhosted�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.bakkinselfhosted-v1.4.7.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bakkinselfhosted.png"1.4(21.4.7B5��������VBakkin Self-hosteden"http://127.0.0.1/
�
BatCave(eu.kanade.tachiyomi.extension.en.batcave�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.batcave-v1.4.6.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.batcave.png"1.4(21.4.6B,����񄦀gBatCaveen"https://batcave.biz
�
!Battle In 5 Seconds After Meeting@eu.kanade.tachiyomi.extension.en.battleinfivesecondsaftermeeting�
|https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.battleinfivesecondsaftermeeting-v1.4.51.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.battleinfivesecondsaftermeeting.png"1.4(321.4.51BJ�犋����#!Battle In 5 Seconds After Meetingen"https://www.deatte5.com
�
Bbato&eu.kanade.tachiyomi.extension.en.bbato�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.bbato-v1.4.1.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bbato.png"1.4(21.4.18B(����Ϡ��Bbatoen"https://bbato.com
�
	BeeHentai*eu.kanade.tachiyomi.extension.en.beehentai�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.beehentai-v1.4.24.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.beehentai.png"1.4(21.4.248B0�����ٖ�5	BeeHentaien"https://beehentai.com
�

BookWalker+eu.kanade.tachiyomi.extension.en.bookwalker�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.bookwalker-v1.4.7.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bookwalker.png"1.4(21.4.78B2������&
BookWalkeren"https://bookwalker.com
�
Borat Scans+eu.kanade.tachiyomi.extension.en.boratscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.boratscans-v1.4.51.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.boratscans.png"1.4(321.4.51B3�������mBorat Scansen"https://boratscans.com
�
Broccoli Soup-eu.kanade.tachiyomi.extension.en.broccolisoup�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.broccolisoup-v1.4.1.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.broccolisoup.png"1.4(21.4.1B8�������Broccoli Soupen"https://politeandgood.com
�
	Bun Manga)eu.kanade.tachiyomi.extension.en.bunmanga�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.bunmanga-v1.4.51.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.bunmanga.png"1.4(321.4.51B/���ڒ��R	Bun Mangaen"https://bunmanga.com
�

buttsmithy+eu.kanade.tachiyomi.extension.en.buttsmithy�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.buttsmithy-v1.4.4.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.buttsmithy.png"1.4(21.4.48B9������G
Buttsmithyen"https://incase.buttsmithy.com
�
Clone Manga+eu.kanade.tachiyomi.extension.en.clonemanga�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.clonemanga-v1.4.3.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.clonemanga.png"1.4(21.4.3B9��������OClone Mangaen"https://manga.clone-army.org
�
Clown Corps+eu.kanade.tachiyomi.extension.en.clowncorps�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.clowncorps-v1.4.3.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.clowncorps.png"1.4(21.4.3B3��������Clown Corpsen"https://clowncorps.net
�
CManhua(eu.kanade.tachiyomi.extension.en.cmanhua�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.cmanhua-v1.4.1.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cmanhua.png"1.4(21.4.18B,�ݯ�����qCManhuaen"https://cmanhua.com
�
Cocomic(eu.kanade.tachiyomi.extension.en.cocomic�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.cocomic-v1.4.53.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cocomic.png"1.4(521.4.538B+���߸���1Cocomicen"https://cocomic.co
�
Coffee Manga,eu.kanade.tachiyomi.extension.en.coffeemanga�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.coffeemanga-v1.4.56.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.coffeemanga.png"1.4(821.4.568B5��ʫ����iCoffee Mangaen"https://coffeemanga.ink
�
Collected Curios0eu.kanade.tachiyomi.extension.en.collectedcurios�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.collectedcurios-v1.4.2.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.collectedcurios.png"1.4(21.4.2BAܛ����ިCollected Curiosen"https://www.collectedcurios.com
�
Comic Asura+eu.kanade.tachiyomi.extension.en.comicasura�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.comicasura-v1.4.34.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comicasura.png"1.4("21.4.348B3�;����Comic Asuraen"https://comicasura.net
�
Comic CX(eu.kanade.tachiyomi.extension.en.comiccx�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.comiccx-v1.4.1.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comiccx.png"1.4(21.4.18B*÷������Comic CXen"https://comic.cx
�
ComicHubFree-eu.kanade.tachiyomi.extension.en.comichubfree�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.comichubfree-v1.4.3.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comichubfree.png"1.4(21.4.3B6巵����� ComicHubFreeen"https://comichubfree.com
�
ComicK Fanmade*eu.kanade.tachiyomi.extension.en.comickfan�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.comickfan-v1.4.3.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comickfan.png"1.4(21.4.38B5�팏̺��ComicK Fanmadeen"https://comickfan.com
�
	ComicLand*eu.kanade.tachiyomi.extension.en.comicland�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.comicland-v1.4.1.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comicland.png"1.4(21.4.18B0��������X	ComicLanden"https://comicland.org
�
Comics Land+eu.kanade.tachiyomi.extension.en.comicsland�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.comicsland-v1.4.32.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comicsland.png"1.4( 21.4.328B3�����ȃ� Comics Landen"https://comicsland.org
�
Comix&eu.kanade.tachiyomi.extension.en.comix�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.comix-v1.4.31.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.comix.png"1.4(21.4.318B'���牆��hComixen"https://comix.to
�
Coolmic(eu.kanade.tachiyomi.extension.en.coolmic�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.coolmic-v1.4.2.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.coolmic.png"1.4(21.4.28B+�����͡ICoolmicen"https://coolmic.me
�

Crow Scans*eu.kanade.tachiyomi.extension.en.crowscans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.crowscans-v1.4.32.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.crowscans.png"1.4( 21.4.32B1����ɓ��
Crow Scansen"https://crowscans.xyz
�
Cucumber Manga.eu.kanade.tachiyomi.extension.en.cucumbermanga�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.cucumbermanga-v1.4.51.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cucumbermanga.png"1.4(321.4.518B9�������5Cucumber Mangaen"https://cucumbermanga.com
�
CulturedWorks.eu.kanade.tachiyomi.extension.en.culturedworks�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.culturedworks-v1.4.33.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.culturedworks.png"1.4(!21.4.338B8����Ę�CulturedWorksen"https://culturedworks.com
�
Cutie Comics,eu.kanade.tachiyomi.extension.en.cutiecomics�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.cutiecomics-v1.4.5.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.cutiecomics.png"1.4(21.4.58B5��ٲ����lCutie Comicsen"https://cutiecomics.com
�
Danke fürs Lesen/eu.kanade.tachiyomi.extension.en.dankefurslesen�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.dankefurslesen-v1.4.7.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dankefurslesen.png"1.4(21.4.78B4�������Danke fürs Lesenen"https://danke.moe
�
Dark Legacy Comics1eu.kanade.tachiyomi.extension.en.darklegacycomics�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.darklegacycomics-v1.4.1.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.darklegacycomics.png"1.4(21.4.1BD����ǲ��Dark Legacy Comicsen" https://www.darklegacycomics.com
�
Dark Science,eu.kanade.tachiyomi.extension.en.darkscience�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.darkscience-v1.4.1.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.darkscience.png"1.4(21.4.1B6��������Dark Scienceen"https://dresdencodak.com
�
Darths & Droids-eu.kanade.tachiyomi.extension.en.darthsdroids�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.darthsdroids-v1.4.2.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.darthsdroids.png"1.4(21.4.2B@�����뒮Darths & Droidsen"https://www.darthsanddroids.net
�
Death Toll Scans/eu.kanade.tachiyomi.extension.en.deathtollscans�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.deathtollscans-v1.4.5.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.deathtollscans.png"1.4(21.4.5BC���Ʈ���ADeath Toll Scansen"!https://reader.deathtollscans.net
�
Decadence Scans/eu.kanade.tachiyomi.extension.en.decadencescans�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.decadencescans-v1.4.53.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.decadencescans.png"1.4(521.4.538BB�ҿ��gDecadence Scansen"!https://reader.decadencescans.com
�

DFlowScans+eu.kanade.tachiyomi.extension.en.dflowscans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.dflowscans-v1.4.1.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dflowscans.png"1.4(21.4.1B8�怗����O
DFlowScansen"https://dflow.alwaysdata.net
�
Digital Comic Museum3eu.kanade.tachiyomi.extension.en.digitalcomicmuseum�
nhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.digitalcomicmuseum-v1.4.4.apk|https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.digitalcomicmuseum.png"1.4(21.4.4BD��­���Digital Comic Museumen"https://digitalcomicmuseum.com
�

Diva Scans*eu.kanade.tachiyomi.extension.en.divascans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.divascans-v1.4.24.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.divascans.png"1.4(21.4.248B1���Ѻ�ÉL
Diva Scansen"https://divascans.org
�
Doujin.io - J18)eu.kanade.tachiyomi.extension.en.doujinio�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.doujinio-v1.4.3.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.doujinio.png"1.4(21.4.38B2ʰ�����&Doujin.io - J18en"https://doujin.io
�
Doujins(eu.kanade.tachiyomi.extension.en.doujins�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.doujins-v1.4.6.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.doujins.png"1.4(21.4.68B,��ʀ����3Doujinsen"https://doujins.com
�
	DragonTea*eu.kanade.tachiyomi.extension.en.dragontea�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.dragontea-v1.4.56.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dragontea.png"1.4(821.4.56B0�贙���[	DragonTeaen"https://dragontea.ink
�
Drake Scans+eu.kanade.tachiyomi.extension.en.drakescans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.drakescans-v1.4.48.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.drakescans.png"1.4(021.4.48B3��ă����rDrake Scansen"https://drakecomic.org
�
Dynasty(eu.kanade.tachiyomi.extension.en.dynasty�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.dynasty-v1.4.30.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.dynasty.png"1.4(21.4.308B8���ۡ�Ƥ	Dynasty Scansen"https://dynasty-scans.com
�
Eggporncomics.eu.kanade.tachiyomi.extension.en.eggporncomics�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.eggporncomics-v1.4.3.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.eggporncomics.png"1.4(21.4.38B8��ۗꐗ�dEggporncomicsen"https://eggporncomics.com
�
El Goonish Shive*eu.kanade.tachiyomi.extension.en.egscomics�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.egscomics-v1.4.2.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.egscomics.png"1.4(21.4.2B;�����\El Goonish Shiveen"https://www.egscomics.com
�
18 Porn Comic2eu.kanade.tachiyomi.extension.en.eighteenporncomic�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.eighteenporncomic-v1.4.3.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.eighteenporncomic.png"1.4(21.4.38B6��͎����G18 Porn Comicen"https://18porncomic.com
�
8Muses+eu.kanade.tachiyomi.extension.en.eightmuses�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.eightmuses-v1.4.2.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.eightmuses.png"1.4(21.4.28B1������8Musesen"https://comics.8muses.com
�
Elan School+eu.kanade.tachiyomi.extension.en.elanschool�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.elanschool-v1.4.1.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.elanschool.png"1.4(21.4.1B0����郔�UElan Schoolen"https://elan.school
�
Elf Toon(eu.kanade.tachiyomi.extension.en.elftoon�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.elftoon-v1.4.34.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.elftoon.png"1.4("21.4.34B-��������6Elf Toonen"https://elftoon.com
�
emaqi&eu.kanade.tachiyomi.extension.en.emaqi�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.emaqi-v1.4.1.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.emaqi.png"1.4(21.4.18B(��������.emaqien"https://emaqi.com
�
	EpicManga*eu.kanade.tachiyomi.extension.en.epicmanga�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.epicmanga-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.epicmanga.png"1.4(321.4.518B/𖿊��Σo	EpicMangaen"https://epicmanga.co
�

Eris Scans*eu.kanade.tachiyomi.extension.en.erisscans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.erisscans-v1.4.20.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.erisscans.png"1.4(21.4.208B1��̴����s
Eris Scansen"https://erisscans.com
�
Ero18x'eu.kanade.tachiyomi.extension.en.ero18x�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.ero18x-v1.4.51.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ero18x.png"1.4(321.4.518B*����۱�QEro18xen"https://ero18x.com
�
Erofus'eu.kanade.tachiyomi.extension.en.erofus�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.erofus-v1.4.3.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.erofus.png"1.4(21.4.38B.ȴ����߲*Erofusen"https://www.erofus.com
�
Scythe Scans*eu.kanade.tachiyomi.extension.en.erosscans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.erosscans-v1.4.39.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.erosscans.png"1.4('21.4.39B5�������Scythe Scansen"https://scythescans.com
�
	Eva Scans)eu.kanade.tachiyomi.extension.en.evascans�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.evascans-v1.4.34.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.evascans.png"1.4("21.4.34B/�Γ�����	Eva Scansen"https://evascans.org
�
Existential Comics2eu.kanade.tachiyomi.extension.en.existentialcomics�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.existentialcomics-v1.4.5.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.existentialcomics.png"1.4(21.4.5BA�޶�����	Existential Comicsen"https://existentialcomics.com
�
Cyanide & Happiness(eu.kanade.tachiyomi.extension.en.explosm�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.explosm-v1.4.5.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.explosm.png"1.4(21.4.5B8��������Cyanide & Happinessen"https://explosm.net
�
EZmanga(eu.kanade.tachiyomi.extension.en.ezmanga�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.ezmanga-v1.4.62.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ezmanga.png"1.4(>21.4.62B,�،�ĵ�.EZmangaen"https://ezmanga.org
�
Fable Scans+eu.kanade.tachiyomi.extension.en.fablescans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.fablescans-v1.4.32.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.fablescans.png"1.4( 21.4.328B3�̤���CFable Scansen"https://fablescans.com
�
Fairy Scans+eu.kanade.tachiyomi.extension.en.fairyscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.fairyscans-v1.4.33.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.fairyscans.png"1.4(!21.4.338B3����ȣ��lFairy Scansen"https://fairyscans.com
�
	Firescans*eu.kanade.tachiyomi.extension.en.firescans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.firescans-v1.4.55.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.firescans.png"1.4(721.4.55B0�Ğ��ܴ�O	Firescansen"https://firescans.xyz
�
Flame Comics,eu.kanade.tachiyomi.extension.en.flamecomics�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.flamecomics-v1.4.49.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.flamecomics.png"1.4(121.4.49B5����욈�vFlame Comicsen"https://flamecomics.xyz
�
Frieren Online.eu.kanade.tachiyomi.extension.en.frierenonline�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.frierenonline-v1.4.51.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.frierenonline.png"1.4(321.4.51B9���ȹ��1Frieren Onlineen"https://www.frieren.online
�

GakaMangas+eu.kanade.tachiyomi.extension.en.gakamangas�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.gakamangas-v1.4.51.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gakamangas.png"1.4(321.4.51B2�������H
GakaMangasen"https://gakamangas.com
�
GalaxyDegenScans1eu.kanade.tachiyomi.extension.en.galaxydegenscans�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.galaxydegenscans-v1.4.55.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.galaxydegenscans.png"1.4(721.4.558B5�Ͱ����?GalaxyDegenScansen"https://gdscans.com
�
Galaxy Manga,eu.kanade.tachiyomi.extension.en.galaxymanga�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.galaxymanga-v1.4.32.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.galaxymanga.png"1.4( 21.4.328B4؜������*Galaxy Mangaen"https://galaxymanga.io
�

GEDE Comix*eu.kanade.tachiyomi.extension.en.gedecomix�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.gedecomix-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gedecomix.png"1.4(321.4.518B1�מ�����6
GEDE Comixen"https://gedecomix.com
�

GingeRTooN+eu.kanade.tachiyomi.extension.en.gingertoon�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.gingertoon-v1.4.51.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gingertoon.png"1.4(321.4.518B2��Ś���:
GingeRTooNen"https://gingertoon.com
�
GirlsTop)eu.kanade.tachiyomi.extension.en.girlstop�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.girlstop-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.girlstop.png"1.4(21.4.18B2�����ǟ�GirlsTopen"https://en.girlstop.info
�
Goda%eu.kanade.tachiyomi.extension.en.goda�
`https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.goda-v1.4.3.apknhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.goda.png"1.4(21.4.3B-⏣�����;Godaen"https://manhuascans.org
�
Gourmet Scans-eu.kanade.tachiyomi.extension.en.gourmetscans�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.gourmetscans-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gourmetscans.png"1.4(321.4.518B;��갲�ģ3Gourmet Scansen"https://gourmetsupremacy.com
�
Greed Scans+eu.kanade.tachiyomi.extension.en.greedscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.greedscans-v1.4.32.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.greedscans.png"1.4( 21.4.32B2������Greed Scansen"https://gojoscans.com
�

Grim Scans*eu.kanade.tachiyomi.extension.en.grimscans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.grimscans-v1.4.20.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.grimscans.png"1.4(21.4.20B1������Șw
Grim Scansen"https://grimscans.com
�
Grrl Power Comic*eu.kanade.tachiyomi.extension.en.grrlpower�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.grrlpower-v1.4.4.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.grrlpower.png"1.4(21.4.4B@��ښ����Grrl Power Comicen"https://www.grrlpowercomic.com
�
Gunnerkrigg Court1eu.kanade.tachiyomi.extension.en.gunnerkriggcourt�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.gunnerkriggcourt-v1.4.3.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gunnerkriggcourt.png"1.4(21.4.3B>��ֆ����SGunnerkrigg Courten"https://www.gunnerkrigg.com
�
Guya%eu.kanade.tachiyomi.extension.en.guya�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.guya-v1.4.25.apknhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.guya.png"1.4(21.4.25B-������خ@Guyaen"https://guya.cubari.moe
�
Gone with the Blastwave%eu.kanade.tachiyomi.extension.en.gwtb�
`https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.gwtb-v1.4.3.apknhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.gwtb.png"1.4(21.4.3BH܃߃����7Gone with the Blastwaveen"https://www.blastwave-comic.com
�
	Hachirumi*eu.kanade.tachiyomi.extension.en.hachirumi�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hachirumi-v1.4.7.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hachirumi.png"1.4(21.4.78B0�������	Hachirumien"https://hachirumi.com
�
Hades Scans+eu.kanade.tachiyomi.extension.en.hadesscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hadesscans-v1.4.33.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hadesscans.png"1.4(!21.4.33B3����Ɣ�<Hades Scansen"https://hadesscans.com
�
Hentai3z.CC+eu.kanade.tachiyomi.extension.en.hentai3zcc�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentai3zcc-v1.4.3.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentai3zcc.png"1.4(21.4.38B0樳����Hentai3z.CCen"https://hentai3z.cc
�
Hentai4Free,eu.kanade.tachiyomi.extension.en.hentai4free�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentai4free-v1.4.51.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentai4free.png"1.4(321.4.518B4�쒢����[Hentai4Freeen"https://hentai4free.net
�
	HentaiDex*eu.kanade.tachiyomi.extension.en.hentaidex�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentaidex-v1.4.34.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaidex.png"1.4("21.4.348B0��������	HentaiDexen"https://dexhentai.com
�

HentaiHere+eu.kanade.tachiyomi.extension.en.hentaihere�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentaihere-v1.4.7.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaihere.png"1.4(21.4.78B2���Ŕ���d
HentaiHereen"https://hentaihere.com
�

HentaiKisu+eu.kanade.tachiyomi.extension.en.hentaikisu�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentaikisu-v1.4.1.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaikisu.png"1.4(21.4.18B2Ǝ�Ӵ��J
HentaiKisuen"https://hentaikisu.com
�
	HentaiKun*eu.kanade.tachiyomi.extension.en.hentaikun�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentaikun-v1.4.1.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaikun.png"1.4(21.4.18B0�ׂ쿸�!	HentaiKunen"https://hentaikun.com
�
HentaiNexus,eu.kanade.tachiyomi.extension.en.hentainexus�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentainexus-v1.4.18.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentainexus.png"1.4(21.4.188B4��������kHentaiNexusen"https://hentainexus.com
�

HentaiRead+eu.kanade.tachiyomi.extension.en.hentairead�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentairead-v1.4.61.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentairead.png"1.4(=21.4.618B2��ࡲ���
HentaiReaden"https://hentairead.com
�
HentaiRead.io-eu.kanade.tachiyomi.extension.en.hentaireadio�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentaireadio-v1.4.1.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaireadio.png"1.4(21.4.18B4���䫙��HentaiRead.ioen"https://hentairead.io
�
	HentaiSco*eu.kanade.tachiyomi.extension.en.hentaisco�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentaisco-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaisco.png"1.4(321.4.518B/֎ܯ���]	HentaiScoen"https://hentaisco.cc
�
HentaiXComic-eu.kanade.tachiyomi.extension.en.hentaixcomic�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentaixcomic-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaixcomic.png"1.4(321.4.518B6�����ƮjHentaiXComicen"https://hentaixcomic.com
�
HentaiXDickgirl0eu.kanade.tachiyomi.extension.en.hentaixdickgirl�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentaixdickgirl-v1.4.51.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaixdickgirl.png"1.4(321.4.518B<�Ǖ�����HentaiXDickgirlen"https://hentaixdickgirl.com
�
HentaiXYuri,eu.kanade.tachiyomi.extension.en.hentaixyuri�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentaixyuri-v1.4.51.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentaixyuri.png"1.4(321.4.518B4��Ҟ�Х�HentaiXYurien"https://hentaixyuri.com
�
Hentara(eu.kanade.tachiyomi.extension.en.hentara�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hentara-v1.4.3.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hentara.png"1.4(21.4.38B,倌��߰�aHentaraen"https://hentara.com
�
HeyToon(eu.kanade.tachiyomi.extension.en.heytoon�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.heytoon-v1.4.1.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.heytoon.png"1.4(21.4.18B,�����ևHHeyToonen"https://heytoon.net
�
Hijala Scans,eu.kanade.tachiyomi.extension.en.hijalascans�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hijalascans-v1.4.23.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hijalascans.png"1.4(21.4.23B3�ԅ�����Hijala Scansen"https://en-hijala.com
�
Hiperdex)eu.kanade.tachiyomi.extension.en.hiperdex�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hiperdex-v1.4.80.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hiperdex.png"1.4(P21.4.808B.�םό�*Hiperdexen"https://hiperdex.com
�
Hiveworks Comics*eu.kanade.tachiyomi.extension.en.hiveworks�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hiveworks-v1.4.12.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hiveworks.png"1.4(21.4.12B=���ݶ���[Hiveworks Comicsen"https://hiveworkscomics.com
�
HM2D%eu.kanade.tachiyomi.extension.en.hm2d�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hm2d-v1.4.53.apknhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hm2d.png"1.4(521.4.538B0����՞��eHM2Den"https://doujindistrict.com
�
HonkaiImpact3-eu.kanade.tachiyomi.extension.en.honkaiimpact�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.honkaiimpact-v1.4.4.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.honkaiimpact.png"1.4(21.4.4BB����ꌹNHonkai Impact 3rden"https://manga.honkaiimpact3.com
�
	HotComics*eu.kanade.tachiyomi.extension.en.hotcomics�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hotcomics-v1.4.2.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hotcomics.png"1.4(21.4.28B/������W	HotComicsen"https://hotcomics.me
�
Hyakuro Translations(eu.kanade.tachiyomi.extension.en.hyakuro�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.hyakuro-v1.4.1.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.hyakuro.png"1.4(21.4.18B9�������EHyakuro Translationsen"https://hyakuro.net
�
I,eu.kanade.tachiyomi.extension.en.imanevilgod�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.imanevilgod-v1.4.7.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.imanevilgod.png"1.4(21.4.7B8�������kI'm An Evil Goden"https://imanevilgod.com
�

Hive Scans2eu.kanade.tachiyomi.extension.en.infernalvoidscans�
nhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.infernalvoidscans-v1.4.65.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.infernalvoidscans.png"1.4(A21.4.65B1��������W
Hive Scansen"https://hivetoons.org
�
InfinityScans.eu.kanade.tachiyomi.extension.en.infinityscans�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.infinityscans-v1.4.10.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.infinityscans.png"1.4(
21.4.108B8�ջ����kInfinityScansen"https://infinityscans.org
�
I Roved Out*eu.kanade.tachiyomi.extension.en.irovedout�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.irovedout-v1.4.5.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.irovedout.png"1.4(21.4.58B6��㗿���qI Roved Outen"https://www.irovedout.com
�
IsekaiScan.top (unoriginal).eu.kanade.tachiyomi.extension.en.isekaiscantop�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.isekaiscantop-v1.4.52.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.isekaiscantop.png"1.4(421.4.528BC׆������'IsekaiScan.top (unoriginal)en"https://isekaiscan.top
�
	Jinmangas*eu.kanade.tachiyomi.extension.en.jinmangas�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.jinmangas-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.jinmangas.png"1.4(321.4.518B0�������O	Jinmangasen"https://jinmangas.com
�
J-Novel'eu.kanade.tachiyomi.extension.en.jnovel�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.jnovel-v1.4.4.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.jnovel.png"1.4(21.4.4B-������"J-Novelen"https://j-novel.club
�
Kaizen Scan+eu.kanade.tachiyomi.extension.en.kaizenscan�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kaizenscan-v1.4.20.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaizenscan.png"1.4(21.4.208B3��ƲŬ��Kaizen Scanen"https://kaizenscan.com
�
KaliScan,eu.kanade.tachiyomi.extension.en.kaliscancom�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kaliscancom-v1.4.25.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaliscancom.png"1.4(21.4.258B.����ͱ��jKaliScanen"https://kaliscan.com
�
Kappa Beast+eu.kanade.tachiyomi.extension.en.kappabeast�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kappabeast-v1.4.33.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kappabeast.png"1.4(!21.4.338B3����뾀�$Kappa Beasten"https://kappabeast.com
�

Kayn Scans*eu.kanade.tachiyomi.extension.en.kaynscans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kaynscans-v1.4.27.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kaynscans.png"1.4(21.4.27B0�������/
Kayn Scansen"https://kaynscan.org
�
keenspot)eu.kanade.tachiyomi.extension.en.keenspot�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.keenspot-v1.4.3.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.keenspot.png"1.4(21.4.3B@�休����+Keenspot TwoKindsen"https://twokinds.keenspot.com
�
	Ken Scans)eu.kanade.tachiyomi.extension.en.kenscans�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kenscans-v1.4.33.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kenscans.png"1.4(!21.4.33B0���ڴ��l	Ken Scansen"https://kencomics.com
�

Kewn Scans*eu.kanade.tachiyomi.extension.en.kewnscans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kewnscans-v1.4.21.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kewnscans.png"1.4(21.4.21B1��Ѻ��ˋ'
Kewn Scansen"https://kewnscans.org
�
Kill Six Billion Demons5eu.kanade.tachiyomi.extension.en.killsixbilliondemons�
phttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.killsixbilliondemons-v1.4.6.apk~https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.killsixbilliondemons.png"1.4(21.4.6BF՛ݱ����LKillSixBillionDemonsen" https://killsixbilliondemons.com
�
	KingComiX*eu.kanade.tachiyomi.extension.en.kingcomix�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kingcomix-v1.4.1.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kingcomix.png"1.4(21.4.18B0������Ơ|	KingComiXen"https://kingcomix.com
�
King of Shojo,eu.kanade.tachiyomi.extension.en.kingofshojo�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kingofshojo-v1.4.32.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kingofshojo.png"1.4( 21.4.328B6��������King of Shojoen"https://kingofshojo.com
�
Kissmanga.in,eu.kanade.tachiyomi.extension.en.kissmangain�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kissmangain-v1.4.55.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kissmangain.png"1.4(721.4.558B2��ꠁ�ژ+Kissmanga.inen"https://kissmanga.in
�
K Manga'eu.kanade.tachiyomi.extension.en.kmanga�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kmanga-v1.4.5.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kmanga.png"1.4(21.4.5B4������ԁqK Mangaen"https://kmanga.kodansha.com
�
Kodansha)eu.kanade.tachiyomi.extension.en.kodansha�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kodansha-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kodansha.png"1.4(21.4.18B-������˝Kodanshaen"https://kodansha.us
�
KSGroupScans-eu.kanade.tachiyomi.extension.en.ksgroupscans�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.ksgroupscans-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ksgroupscans.png"1.4(321.4.518B6��̮���;KSGroupScansen"https://ksgroupscans.com
�
Kun Manga Online/eu.kanade.tachiyomi.extension.en.kunmangaonline�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kunmangaonline-v1.4.52.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kunmangaonline.png"1.4(421.4.528B=������nKun Manga Onlineen"https://www.kunmanga.online
�
	KuraManga*eu.kanade.tachiyomi.extension.en.kuramanga�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.kuramanga-v1.4.2.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.kuramanga.png"1.4(21.4.28B0��������b	KuraMangaen"https://kuramanga.com
�
Lagoon Scans,eu.kanade.tachiyomi.extension.en.lagoonscans�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.lagoonscans-v1.4.32.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lagoonscans.png"1.4( 21.4.32B5��к�ڤ�mLagoon Scansen"https://lagoonscans.com
�
Leslie&Victims.eu.kanade.tachiyomi.extension.en.leslievictims�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.leslievictims-v1.4.1.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.leslievictims.png"1.4(21.4.1B@������̅Leslie&Victimsen" https://leslie-victims.pages.dev
�
LHTranslation.eu.kanade.tachiyomi.extension.en.lhtranslation�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.lhtranslation-v1.4.52.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lhtranslation.png"1.4(421.4.52B8�楕��ɔzLHTranslationen"https://lhtranslation.net
�
	LikeManga*eu.kanade.tachiyomi.extension.en.likemanga�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.likemanga-v1.4.8.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.likemanga.png"1.4(21.4.8B0��ݪ����V	LikeMangaen"https://likemanga.ink
�
MangaYY,eu.kanade.tachiyomi.extension.en.likemangain�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.likemangain-v1.4.52.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.likemangain.png"1.4(421.4.528B,���䇞��MangaYYen"https://mangayy.org
�

Lily Manga*eu.kanade.tachiyomi.extension.en.lilymanga�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.lilymanga-v1.4.58.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lilymanga.png"1.4(:21.4.588B1��灾��>
Lily Mangaen"https://lilymanga.net
�
	LinkManga*eu.kanade.tachiyomi.extension.en.linkmanga�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.linkmanga-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.linkmanga.png"1.4(321.4.518B0��������w	LinkMangaen"https://linkmanga.com
�
Loading Artist.eu.kanade.tachiyomi.extension.en.loadingartist�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.loadingartist-v1.4.3.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.loadingartist.png"1.4(21.4.3B9������Loading Artisten"https://loadingartist.com
�
	Lua Scans)eu.kanade.tachiyomi.extension.en.luascans�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.luascans-v1.4.51.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.luascans.png"1.4(321.4.51B/��������	Lua Scansen"https://luacomic.org
�
Luminare Translations5eu.kanade.tachiyomi.extension.en.luminaretranslations�
phttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.luminaretranslations-v1.4.3.apk~https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.luminaretranslations.png"1.4(21.4.3BG��������Luminare Translationsen" https://luminaretranslations.com
�

Luna Toons*eu.kanade.tachiyomi.extension.en.lunatoons�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.lunatoons-v1.4.20.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lunatoons.png"1.4(21.4.208B1��쇨��
Luna Toonsen"https://lunatoons.org
�
LustToon)eu.kanade.tachiyomi.extension.en.lusttoon�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.lusttoon-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.lusttoon.png"1.4(21.4.18B-�������KLustToonen"https://lustoon.com
�
	MadaraDex*eu.kanade.tachiyomi.extension.en.madaradex�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.madaradex-v1.4.54.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.madaradex.png"1.4(621.4.548B0ǐ������	MadaraDexen"https://madaradex.org
�
Madara Scans,eu.kanade.tachiyomi.extension.en.madarascans�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.madarascans-v1.4.34.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.madarascans.png"1.4("21.4.34B5������Ϡ}Madara Scansen"https://madarascans.com
�
Madokami)eu.kanade.tachiyomi.extension.en.madokami�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.madokami-v1.4.14.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.madokami.png"1.4(21.4.14B3Ѷ�Ӗ���eMadokamien"https://manga.madokami.al
�
Magus Manga+eu.kanade.tachiyomi.extension.en.magusmanga�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.magusmanga-v1.4.69.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.magusmanga.png"1.4(E21.4.69B2��������Magus Mangaen"https://magustoon.org
�
Mahouirexnohentaikarte7eu.kanade.tachiyomi.extension.en.mahouirexnohentaikarte�
shttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mahouirexnohentaikarte-v1.4.51.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mahouirexnohentaikarte.png"1.4(321.4.518BJ�ͬ�����Mahouirexnohentaikarteen""https://mahouirexnohentaikarte.com
�
Manga18.Club,eu.kanade.tachiyomi.extension.en.manga18club�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manga18club-v1.4.3.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18club.png"1.4(21.4.38B2ḉ�����/Manga18.Cluben"https://manga18.club
�
Manga18Free,eu.kanade.tachiyomi.extension.en.manga18free�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manga18free-v1.4.52.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18free.png"1.4(421.4.528B4��������=Manga18Freeen"https://manga18free.com
�
	Manga18fx*eu.kanade.tachiyomi.extension.en.manga18fx�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manga18fx-v1.4.56.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18fx.png"1.4(821.4.568B0������+	Manga18fxen"https://manga18fx.com
�
	Manga 18x)eu.kanade.tachiyomi.extension.en.manga18x�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manga18x-v1.4.52.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manga18x.png"1.4(421.4.528B/���ە��^	Manga 18xen"https://manga18x.net
�
Mangabat)eu.kanade.tachiyomi.extension.en.mangabat�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangabat-v1.4.20.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabat.png"1.4(21.4.208B3ڲ򭄪��:Mangabaten"https://www.mangabats.com
�
	Manga-Bay)eu.kanade.tachiyomi.extension.en.mangabay�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangabay-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabay.png"1.4(21.4.18B5þ���ឹ 	Manga-Bayen"https://read.manga-bay.org
�

MangaBlaze+eu.kanade.tachiyomi.extension.en.mangablaze�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangablaze-v1.4.52.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangablaze.png"1.4(421.4.52B2��悙³�U
MangaBlazeen"https://mangablaze.com
�
	MangaBolt*eu.kanade.tachiyomi.extension.en.mangabolt�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangabolt-v1.4.1.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabolt.png"1.4(21.4.1B0��堂��	MangaBolten"https://mangabolt.com
�
MangaBTT)eu.kanade.tachiyomi.extension.en.mangabtt�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangabtt-v1.4.5.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabtt.png"1.4(21.4.58B.���ޚ���lMangaBTTen"https://manhwabtt.cc
�
MangaK+eu.kanade.tachiyomi.extension.en.mangabuddy�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangabuddy-v1.4.30.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangabuddy.png"1.4(21.4.308B)�����ց�EMangaKen"https://mangak.io
�
Mangack(eu.kanade.tachiyomi.extension.en.mangack�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangack-v1.4.2.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangack.png"1.4(21.4.2B,��č����dMangacken"https://mangack.com
�

MangaCloud+eu.kanade.tachiyomi.extension.en.mangacloud�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangacloud-v1.4.7.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangacloud.png"1.4(21.4.7B2�������y
MangaClouden"https://mangacloud.org
�

Manga Dass*eu.kanade.tachiyomi.extension.en.mangadass�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangadass-v1.4.52.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadass.png"1.4(421.4.528B1���ϕ��M
Manga Dassen"https://mangadass.com
�
MangaDE(eu.kanade.tachiyomi.extension.en.mangade�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangade-v1.4.1.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangade.png"1.4(21.4.18B+����ƞ��/MangaDEen"https://mangade.io
�
Manga Demon+eu.kanade.tachiyomi.extension.en.mangademon�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangademon-v1.4.19.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangademon.png"1.4(21.4.19B5ڹ�ܒ���(Manga Demonen"https://demonicscans.org
�
MangaDia)eu.kanade.tachiyomi.extension.en.mangadia�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangadia-v1.4.51.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadia.png"1.4(321.4.51B.�ҥă��MangaDiaen"https://mangadia.com
�
Manga District.eu.kanade.tachiyomi.extension.en.mangadistrict�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangadistrict-v1.4.67.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadistrict.png"1.4(C21.4.678B9��������)Manga Districten"https://mangadistrict.com
�
Mangadotnet,eu.kanade.tachiyomi.extension.en.mangadotnet�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangadotnet-v1.4.11.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadotnet.png"1.4(21.4.118B1��ٙ�ɕ�QMangadotneten"https://mangadot.net
�
Manga Drama+eu.kanade.tachiyomi.extension.en.mangadrama�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangadrama-v1.4.51.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangadrama.png"1.4(321.4.518B3�������,Manga Dramaen"https://mangadrama.com
�
Mangaforfree.com0eu.kanade.tachiyomi.extension.en.mangaforfreecom�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangaforfreecom-v1.4.53.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaforfreecom.png"1.4(521.4.538B:����ԗΠMangaforfree.comen"https://mangaforfree.com
�
MangaFox)eu.kanade.tachiyomi.extension.en.mangafox�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangafox-v1.4.9.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafox.png"1.4(	21.4.98B,Ц������YMangaFoxen"https://fanfox.net
�
MangaFox.fun,eu.kanade.tachiyomi.extension.en.mangafoxfun�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangafoxfun-v1.4.35.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafoxfun.png"1.4(#21.4.358B2������߂qMangaFox.funen"https://mangafox.fun
�

Mangafreak+eu.kanade.tachiyomi.extension.en.mangafreak�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangafreak-v1.4.13.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafreak.png"1.4(21.4.138B5�֬����
Mangafreaken"https://ww2.mangafreak.me
�
	Mangafree*eu.kanade.tachiyomi.extension.en.mangafree�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangafree-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangafree.png"1.4(321.4.518B1��Ԫۧ��.	Mangafreeen"https://mangafree.info
�
MangaGG(eu.kanade.tachiyomi.extension.en.mangagg�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangagg-v1.4.54.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangagg.png"1.4(621.4.548B,Ά���նqMangaGGen"https://mangagg.com
�
Mangago(eu.kanade.tachiyomi.extension.en.mangago�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangago-v1.4.34.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangago.png"1.4("21.4.348B/ژ����ڣ"Mangagoen"https://www.mangago.me
�
MangaGo.fun+eu.kanade.tachiyomi.extension.en.mangagofun�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangagofun-v1.4.51.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangagofun.png"1.4(321.4.51B4��ڑо��XMangaGo.funen"https://www.mangago.fun
�
MangaHe(eu.kanade.tachiyomi.extension.en.mangahe�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangahe-v1.4.51.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahe.png"1.4(321.4.518B,��������MangaHeen"https://mangahe.com
�
Gensura)eu.kanade.tachiyomi.extension.en.mangahen�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangahen-v1.4.3.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahen.png"1.4(21.4.38B,��﫱��[Gensuraen"https://gensura.net
�
Manga Hentai,eu.kanade.tachiyomi.extension.en.mangahentai�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangahentai-v1.4.55.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahentai.png"1.4(721.4.558B4���嘑yManga Hentaien"https://mangahentai.me
�
	Mangahere*eu.kanade.tachiyomi.extension.en.mangahere�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangahere-v1.4.23.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahere.png"1.4(21.4.238B+	Mangahereen"https://www.mangahere.cc
�
MangaHere.onl-eu.kanade.tachiyomi.extension.en.mangahereonl�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangahereonl-v1.4.35.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahereonl.png"1.4(#21.4.358B4��������6MangaHere.onlen"https://mangahere.onl
�
MangaHub+eu.kanade.tachiyomi.extension.en.mangahubio�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangahubio-v1.4.45.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangahubio.png"1.4(-21.4.458B-�ۢ�����BMangaHuben"https://mangahub.io
�
MangaKa(eu.kanade.tachiyomi.extension.en.mangaka�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangaka-v1.4.51.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaka.png"1.4(321.4.51B+��Ɔ����-MangaKaen"https://mangaka.cc
�
Mangakakalot-eu.kanade.tachiyomi.extension.en.mangakakalot�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangakakalot-v1.4.21.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakakalot.png"1.4(21.4.218B9�闥����#Mangakakaloten"https://www.mangakakalot.gg
�
Mangakakalot.fun0eu.kanade.tachiyomi.extension.en.mangakakalotfun�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangakakalotfun-v1.4.35.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakakalotfun.png"1.4(#21.4.358B:������ŊZMangakakalot.funen"https://mangakakalot.fun
�
MangaKatana,eu.kanade.tachiyomi.extension.en.mangakatana�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangakatana-v1.4.12.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakatana.png"1.4(21.4.128B4��������,MangaKatanaen"https://mangakatana.com
�

Manga Kiss*eu.kanade.tachiyomi.extension.en.mangakiss�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangakiss-v1.4.52.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangakiss.png"1.4(421.4.52B1�����І�!
Manga Kissen"https://mangakiss.org
�
MangaManiacs-eu.kanade.tachiyomi.extension.en.mangamaniacs�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangamaniacs-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamaniacs.png"1.4(321.4.518B6������׮LMangaManiacsen"https://mangamaniacs.org
�
Manga Mirai+eu.kanade.tachiyomi.extension.en.mangamirai�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangamirai-v1.4.1.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamirai.png"1.4(21.4.1B3��䳁���/Manga Miraien"https://mangamirai.com
�
Mangamo(eu.kanade.tachiyomi.extension.en.mangamo�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangamo-v1.4.7.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamo.png"1.4(21.4.7B0���ğ��YMangamoen"https://www.mangamo.com
�
Comivex)eu.kanade.tachiyomi.extension.en.mangamob�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangamob-v1.4.3.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangamob.png"1.4(21.4.3B,��������Comivexen"https://comivex.com
�
MangaNel)eu.kanade.tachiyomi.extension.en.manganel�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manganel-v1.4.35.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manganel.png"1.4(#21.4.358B-�㽢����	MangaNelen"https://manganel.me
�
	Manganato*eu.kanade.tachiyomi.extension.en.manganelo�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manganelo-v1.4.18.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manganelo.png"1.4(21.4.188B4��������	Manganatoen"https://www.natomanga.com
�
MangaNow)eu.kanade.tachiyomi.extension.en.manganow�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manganow-v1.4.4.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manganow.png"1.4(21.4.48B-��������MangaNowen"https://manganow.to
�
MangaOnline.fun/eu.kanade.tachiyomi.extension.en.mangaonlinefun�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangaonlinefun-v1.4.35.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaonlinefun.png"1.4(#21.4.358B8�������IMangaOnline.funen"https://mangaonline.fun
�
MangaOwl.io (unoriginal)+eu.kanade.tachiyomi.extension.en.mangaowlio�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangaowlio-v1.4.52.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaowlio.png"1.4(421.4.528B=�ʅ�՘MangaOwl.io (unoriginal)en"https://mangaowl.io
�
MangaPanda.onl.eu.kanade.tachiyomi.extension.en.mangapandaonl�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangapandaonl-v1.4.35.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangapandaonl.png"1.4(#21.4.35B6����ڴ�jMangaPanda.onlen"https://mangapanda.onl
�
	MangaPill*eu.kanade.tachiyomi.extension.en.mangapill�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangapill-v1.4.9.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangapill.png"1.4(	21.4.98B0��ҧҩ��u	MangaPillen"https://mangapill.com
�
	MangaGeko-eu.kanade.tachiyomi.extension.en.mangarawclub�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangarawclub-v1.4.32.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangarawclub.png"1.4( 21.4.328B/���ۊ���
	MangaGekoen"https://www.mgeko.cc
�

Manga Read*eu.kanade.tachiyomi.extension.en.mangaread�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangaread-v1.4.52.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangaread.png"1.4(421.4.528B0����֘��z
Manga Readen"https://mangaread.co
�
MangaReader.in.eu.kanade.tachiyomi.extension.en.mangareadercc�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangareadercc-v1.4.6.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangareadercc.png"1.4(21.4.68B6ٺ������fMangaReader.inen"https://mangareader.in
�
MangaReader.site0eu.kanade.tachiyomi.extension.en.mangareadersite�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangareadersite-v1.4.35.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangareadersite.png"1.4(#21.4.35B:���ԘŚ�#MangaReader.siteen"https://mangareader.site
�
MangaRead.org-eu.kanade.tachiyomi.extension.en.mangareadorg�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangareadorg-v1.4.53.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangareadorg.png"1.4(521.4.538B8�۷���ț%MangaRead.orgen"https://www.mangaread.org
�

Mangasushi+eu.kanade.tachiyomi.extension.en.mangasushi�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangasushi-v1.4.54.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangasushi.png"1.4(621.4.54B2�۸����2
Mangasushien"https://mangasushi.org
�

MangaToday+eu.kanade.tachiyomi.extension.en.mangatoday�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangatoday-v1.4.35.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatoday.png"1.4(#21.4.358B2�������
MangaTodayen"https://mangatoday.fun
�
	Mangatown*eu.kanade.tachiyomi.extension.en.mangatown�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangatown-v1.4.10.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatown.png"1.4(
21.4.108B4���Ԩ���%	Mangatownen"https://www.mangatown.com
�
Manga Trend+eu.kanade.tachiyomi.extension.en.mangatrend�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangatrend-v1.4.32.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatrend.png"1.4( 21.4.32B3�������Manga Trenden"https://mangatrend.org
�
MangaTX(eu.kanade.tachiyomi.extension.en.mangatx�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mangatx-v1.4.33.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mangatx.png"1.4(!21.4.338B+������-MangaTXen"https://mangatx.cc
�

ManhuaFast+eu.kanade.tachiyomi.extension.en.manhuafast�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhuafast-v1.4.55.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuafast.png"1.4(721.4.558B2̗�Ӓ��K
ManhuaFasten"https://manhuafast.com
�
ManhuaFast.net (unoriginal).eu.kanade.tachiyomi.extension.en.manhuafastnet�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhuafastnet-v1.4.51.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuafastnet.png"1.4(321.4.51BC٘�����6ManhuaFast.net (unoriginal)en"https://manhuafast.net
�
	ManhuaHot*eu.kanade.tachiyomi.extension.en.manhuahot�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhuahot-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuahot.png"1.4(321.4.51B0�����Հj	ManhuaHoten"https://manhuahot.com
�

Manhuanext+eu.kanade.tachiyomi.extension.en.manhuanext�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhuanext-v1.4.52.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuanext.png"1.4(421.4.52B2��ʂ΄��1
Manhuanexten"https://manhuanext.com
�
Manhua Plus+eu.kanade.tachiyomi.extension.en.manhuaplus�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhuaplus-v1.4.58.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuaplus.png"1.4(:21.4.58B3�������}Manhua Plusen"https://manhuaplus.com
�
ManhuaPlus (unoriginal).eu.kanade.tachiyomi.extension.en.manhuaplusorg�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhuaplusorg-v1.4.6.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuaplusorg.png"1.4(21.4.6B?�����ޕ�FManhuaPlus (Unoriginal)en"https://manhuaplus.org
�
Manhua Rush+eu.kanade.tachiyomi.extension.en.manhuarush�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhuarush-v1.4.2.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuarush.png"1.4(21.4.2B:ҟƔ����NManhua Rushen"https://manhuarush.vercel.app
�
Manhuascan.us-eu.kanade.tachiyomi.extension.en.manhuascanus�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhuascanus-v1.4.32.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuascanus.png"1.4( 21.4.328B4��������ZManhuascan.usen"https://manhuascan.us
�
	ManhuaTop*eu.kanade.tachiyomi.extension.en.manhuatop�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhuatop-v1.4.52.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuatop.png"1.4(421.4.528B0ܪ�聾�	ManhuaTopen"https://manhuatop.org
�
ManhuaUS)eu.kanade.tachiyomi.extension.en.manhuaus�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhuaus-v1.4.56.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuaus.png"1.4(821.4.56B.��֞��7ManhuaUSen"https://manhuaus.com
�
Manhua Zonghe-eu.kanade.tachiyomi.extension.en.manhuazonghe�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhuazonghe-v1.4.52.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhuazonghe.png"1.4(421.4.528B;�����TManhua Zongheen"https://www.manhuazonghe.com
�
Manhwa18)eu.kanade.tachiyomi.extension.en.manhwa18�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwa18-v1.4.13.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwa18.png"1.4(21.4.138B-�ڐ��̋2Manhwa18en"https://manhwa18.com
�
Manhwa18.org,eu.kanade.tachiyomi.extension.en.manhwa18org�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwa18org-v1.4.53.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwa18org.png"1.4(521.4.538B2��橽��|Manhwa18.orgen"https://manhwa18.org
�
Manhwa68)eu.kanade.tachiyomi.extension.en.manhwa68�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwa68-v1.4.54.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwa68.png"1.4(621.4.548B.��߇܋�%Manhwa68en"https://manhwa68.com
�
ManhwaBuddy,eu.kanade.tachiyomi.extension.en.manhwabuddy�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwabuddy-v1.4.3.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwabuddy.png"1.4(21.4.38B4������ManhwaBuddyen"https://manhwabuddy.com
�
Manhwa Comics-eu.kanade.tachiyomi.extension.en.manhwacomics�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwacomics-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwacomics.png"1.4(321.4.518B7爵֢���.Manhwa Comicsen"https://manhwacomics.com
�
	ManhwaDen*eu.kanade.tachiyomi.extension.en.manhwaden�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwaden-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaden.png"1.4(321.4.518B4�̤�����j	ManhwaDenen"https://www.manhwaden.com
�
	ManhwaGet*eu.kanade.tachiyomi.extension.en.manhwaget�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwaget-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaget.png"1.4(321.4.51B0ͨ��ʾ�)	ManhwaGeten"https://manhwaget.com
�
	ManhwaHub*eu.kanade.tachiyomi.extension.en.manhwahub�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwahub-v1.4.5.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwahub.png"1.4(21.4.58B0ن�ڕ���	ManhwaHuben"https://manhwahub.net
�
	Manhwajoy*eu.kanade.tachiyomi.extension.en.manhwajoy�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwajoy-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwajoy.png"1.4(321.4.518B0��������	Manhwajoyen"https://manhwajoy.com
�

Manhwalike+eu.kanade.tachiyomi.extension.en.manhwalike�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwalike-v1.4.3.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwalike.png"1.4(21.4.38B2��������0
Manhwalikeen"https://manhwalike.com
�
Manhwalover,eu.kanade.tachiyomi.extension.en.manhwalover�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwalover-v1.4.32.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwalover.png"1.4( 21.4.328B8�ڮ٦đ�QManhwaloveren"https://www.manhwalover.org
�
ManhwaManhua-eu.kanade.tachiyomi.extension.en.manhwamanhua�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwamanhua-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwamanhua.png"1.4(321.4.518B6Բ�����|ManhwaManhuaen"https://manhwamanhua.com
�
	ManhwaNex*eu.kanade.tachiyomi.extension.en.manhwanex�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwanex-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwanex.png"1.4(321.4.51B0�ۆ����2	ManhwaNexen"https://manhwanex.com
�

ManhwaRead+eu.kanade.tachiyomi.extension.en.manhwaread�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwaread-v1.4.1.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaread.png"1.4(21.4.18BKӋ��Ƀ�
ManhwaReaden"/https://manhwaread.com#, https://manhwaread.org
�
Manhwa Reads,eu.kanade.tachiyomi.extension.en.manhwareads�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwareads-v1.4.51.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwareads.png"1.4(321.4.518B5��������.Manhwa Readsen"https://manhwareads.com
�
Manhwa Toon+eu.kanade.tachiyomi.extension.en.manhwatoon�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwatoon-v1.4.52.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwatoon.png"1.4(421.4.528B6���춂��1Manhwa Toonen"https://www.manhwatoon.me
�
	Manhwatop*eu.kanade.tachiyomi.extension.en.manhwatop�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwatop-v1.4.53.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwatop.png"1.4(521.4.538B0�������G	Manhwatopen"https://manhwatop.com
�
Manhwax(eu.kanade.tachiyomi.extension.en.manhwax�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwax-v1.4.32.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwax.png"1.4( 21.4.328B,�����Ԫ�eManhwaxen"https://manhwax.top
�

Manhwa XXL*eu.kanade.tachiyomi.extension.en.manhwaxxl�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwaxxl-v1.4.6.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaxxl.png"1.4(21.4.68B1��ӯ����
Manhwa XXLen"https://hentaitnt.net
�
ManhwaZ(eu.kanade.tachiyomi.extension.en.manhwaz�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwaz-v1.4.42.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwaz.png"1.4(*21.4.428B,ْ���	ManhwaZen"https://manhwaz.com
�

ManhwaZone+eu.kanade.tachiyomi.extension.en.manhwazone�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.manhwazone-v1.4.1.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.manhwazone.png"1.4(21.4.18B2�Ύ��֡�
ManhwaZoneen"https://manhwazone.com
�
	Megatokyo*eu.kanade.tachiyomi.extension.en.megatokyo�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.megatokyo-v1.4.4.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.megatokyo.png"1.4(21.4.4B0��������$	Megatokyoen"https://megatokyo.com
�
	Mehgazone*eu.kanade.tachiyomi.extension.en.mehgazone�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mehgazone-v1.4.2.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mehgazone.png"1.4(21.4.28B0�뎄뻊�%	Mehgazoneen"https://mehgazone.com
�
MeiToon(eu.kanade.tachiyomi.extension.en.meitoon�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.meitoon-v1.4.20.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.meitoon.png"1.4(21.4.20B,�ʅ����-MeiToonen"https://meitoon.org
�
	Mgread.io)eu.kanade.tachiyomi.extension.en.mgreadio�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mgreadio-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mgreadio.png"1.4(21.4.18B+������	Mgread.ioen"https://mgread.io
�
Milftoon)eu.kanade.tachiyomi.extension.en.milftoon�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.milftoon-v1.4.53.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.milftoon.png"1.4(521.4.538B.��ϜȖ��7Milftoonen"https://milftoon.xxx
�

Mist Scans*eu.kanade.tachiyomi.extension.en.mistscans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mistscans-v1.4.21.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mistscans.png"1.4(21.4.21B1ݤ쓯˞�
Mist Scansen"https://mistscans.com
�
	MLBB Lore)eu.kanade.tachiyomi.extension.en.mlbblore�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.mlbblore-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.mlbblore.png"1.4(21.4.1B@�����MLBB Lore Comicsen"https://play.mobilelegends.com
�
Monochrome Custom1eu.kanade.tachiyomi.extension.en.monochromecustom�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.monochromecustom-v1.4.6.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.monochromecustom.png"1.4(21.4.6BD�������Monochrome Customen"!https://monochromecms.netlify.app
�
Monochrome Scans0eu.kanade.tachiyomi.extension.en.monochromescans�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.monochromescans-v1.4.5.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.monochromescans.png"1.4(21.4.5B8�Ǟ�Ɣ��^Monochrome Scansen"https://manga.d34d.one
�
Multporn)eu.kanade.tachiyomi.extension.en.multporn�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.multporn-v1.4.6.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.multporn.png"1.4(21.4.68B.�����Multpornen"https://multporn.net
�
	MurimScan*eu.kanade.tachiyomi.extension.en.murimscan�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.murimscan-v1.4.49.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.murimscan.png"1.4(121.4.498B6�������L	MurimScanen"https://www.murimscans.site
�
MyAdultComics.eu.kanade.tachiyomi.extension.en.myadultcomics�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.myadultcomics-v1.4.1.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.myadultcomics.png"1.4(21.4.18B8������9MyAdultComicsen"https://myadultcomics.com
�
MyHentaiComics/eu.kanade.tachiyomi.extension.en.myhentaicomics�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.myhentaicomics-v1.4.4.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.myhentaicomics.png"1.4(21.4.48B:�����ǌ�DMyHentaiComicsen"https://myhentaicomics.com
�
MyHentaiGallery0eu.kanade.tachiyomi.extension.en.myhentaigallery�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.myhentaigallery-v1.4.9.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.myhentaigallery.png"1.4(	21.4.98B<���ر��eMyHentaiGalleryen"https://myhentaigallery.com
�
Necro Scans+eu.kanade.tachiyomi.extension.en.necroscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.necroscans-v1.4.20.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.necroscans.png"1.4(21.4.20B3�����BNecro Scansen"https://necroscans.com
�

New Manhwa*eu.kanade.tachiyomi.extension.en.newmanhwa�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.newmanhwa-v1.4.34.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.newmanhwa.png"1.4("21.4.348B1�ϣԀ��2
New Manhwaen"https://newmanhwa.com
�
NexComic)eu.kanade.tachiyomi.extension.en.nexcomic�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.nexcomic-v1.4.32.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nexcomic.png"1.4( 21.4.328B.ε������)NexComicen"https://nexcomic.com
�

Nika Toons*eu.kanade.tachiyomi.extension.en.nikatoons�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.nikatoons-v1.4.32.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nikatoons.png"1.4( 21.4.32B1�����̓�
Nika Toonsen"https://nikatoons.com
�
	NineAnime*eu.kanade.tachiyomi.extension.en.nineanime�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.nineanime-v1.4.6.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nineanime.png"1.4(21.4.68B4����ԯ*	NineAnimeen"https://www.nineanime.com
�

NineHentai+eu.kanade.tachiyomi.extension.en.ninehentai�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.ninehentai-v1.4.6.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ninehentai.png"1.4(21.4.68B.�Ҙ��ݣ�j
NineHentaien"https://9hentai.so
�
Ninekon(eu.kanade.tachiyomi.extension.en.ninekon�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.ninekon-v1.4.1.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ninekon.png"1.4(21.4.18B0�ء�٬��=Ninekonen"https://app.ninekon.com
�
NixManga)eu.kanade.tachiyomi.extension.en.nixmanga�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.nixmanga-v1.4.2.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nixmanga.png"1.4(21.4.28B.�������0NixMangaen"https://nixmanga.com
�
24HNovel)eu.kanade.tachiyomi.extension.en.novel24h�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.novel24h-v1.4.52.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.novel24h.png"1.4(421.4.528B.��������t24HNovelen"https://24hnovel.com
�
	NovelCrow*eu.kanade.tachiyomi.extension.en.novelcrow�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.novelcrow-v1.4.52.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.novelcrow.png"1.4(421.4.528B0ڭ����<	NovelCrowen"https://novelcrow.com
�
Noxen Scans+eu.kanade.tachiyomi.extension.en.noxenscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.noxenscans-v1.4.32.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.noxenscans.png"1.4( 21.4.32B2Ζ�˙���+Noxen Scansen"https://noxenscan.com
�
	Nux Scans)eu.kanade.tachiyomi.extension.en.nuxscans�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.nuxscans-v1.4.2.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nuxscans.png"1.4(21.4.2B?�輊��ŠQ	Nux Scansen"$https://nuxscans-comics.blogspot.com
�

Nyanu Kafe*eu.kanade.tachiyomi.extension.en.nyanukafe�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.nyanukafe-v1.4.21.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nyanukafe.png"1.4(21.4.21B1������)
Nyanu Kafeen"https://nyanukafe.com
�

Nyra Scans*eu.kanade.tachiyomi.extension.en.nyrascans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.nyrascans-v1.4.20.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nyrascans.png"1.4(21.4.208B1�צ����
Nyra Scansen"https://nyrascans.com
�
	Nyx Scans)eu.kanade.tachiyomi.extension.en.nyxscans�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.nyxscans-v1.4.26.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.nyxscans.png"1.4(21.4.26B/�������	Nyx Scansen"https://nyxscans.com
�
OctopusManga-eu.kanade.tachiyomi.extension.en.octopusmanga�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.octopusmanga-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.octopusmanga.png"1.4(321.4.518B6��������#OctopusMangaen"https://octopusmanga.com
�
Oglaf&eu.kanade.tachiyomi.extension.en.oglaf�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.oglaf-v1.4.4.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.oglaf.png"1.4(21.4.48B,������Oglafen"https://www.oglaf.com
�
Oh Joy Sex Toy,eu.kanade.tachiyomi.extension.en.ohjoysextoy�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.ohjoysextoy-v1.4.3.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ohjoysextoy.png"1.4(21.4.38B;��蟈�>Oh Joy Sex Toyen"https://www.ohjoysextoy.com
�
Omega Scans+eu.kanade.tachiyomi.extension.en.omegascans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.omegascans-v1.4.50.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.omegascans.png"1.4(221.4.508B3�֢���ݥOmega Scansen"https://omegascans.org
�
	1Manga.co+eu.kanade.tachiyomi.extension.en.onemangaco�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.onemangaco-v1.4.35.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onemangaco.png"1.4(#21.4.358B,�陾���W	1Manga.coen"https://1manga.co
�
OneManga.info-eu.kanade.tachiyomi.extension.en.onemangainfo�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.onemangainfo-v1.4.35.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onemangainfo.png"1.4(#21.4.358B4���η�OneManga.infoen"https://onemanga.info
�
One Punch Man Online2eu.kanade.tachiyomi.extension.en.onepunchmanonline�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.onepunchmanonline-v1.4.2.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onepunchmanonline.png"1.4(21.4.2B?�΂�ݨȹOne Punch Man Onlineen"https://w11.1punchman.com
�
Only The Best Hentai2eu.kanade.tachiyomi.extension.en.onlythebesthentai�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.onlythebesthentai-v1.4.1.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.onlythebesthentai.png"1.4(21.4.18BC�����Ҵ�QOnly The Best Hentaien"https://onlythebesthentai.com
�
oots%eu.kanade.tachiyomi.extension.en.oots�
`https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.oots-v1.4.3.apknhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.oots.png"1.4(21.4.3BG����酗�`The Order Of The Stick (OOTS)en"https://www.giantitp.com
�
Oppai Stream,eu.kanade.tachiyomi.extension.en.oppaistream�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.oppaistream-v1.4.5.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.oppaistream.png"1.4(21.4.58B7��������Oppai Streamen"https://read.oppai.stream
�

Orchisasia+eu.kanade.tachiyomi.extension.en.orchisasia�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.orchisasia-v1.4.51.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.orchisasia.png"1.4(321.4.518B6�����=
Orchisasiaen"https://www.orchisasia.org
�
Orion Scans+eu.kanade.tachiyomi.extension.en.orionscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.orionscans-v1.4.23.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.orionscans.png"1.4(21.4.23B4���๟��kOrion Scansen"https://orion-scans.com
�
Paradise Scans.eu.kanade.tachiyomi.extension.en.paradisescans�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.paradisescans-v1.4.20.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.paradisescans.png"1.4(21.4.208B8�������RParadiseScansen"https://paradisescans.com
�
Paritehaber,eu.kanade.tachiyomi.extension.en.paritehaber�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.paritehaber-v1.4.52.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.paritehaber.png"1.4(421.4.528B8���¢��3Paritehaberen"https://www.paritehaber.com
�
Patch Friday,eu.kanade.tachiyomi.extension.en.patchfriday�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.patchfriday-v1.4.2.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.patchfriday.png"1.4(21.4.2B5��׏�Ɖ�PPatch Fridayen"https://patchfriday.com
�
	Paw Manga)eu.kanade.tachiyomi.extension.en.pawmanga�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.pawmanga-v1.4.51.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.pawmanga.png"1.4(321.4.518B/ѿ�ߧ���>	Paw Mangaen"https://pawmanga.com
�
Petrotechsociety1eu.kanade.tachiyomi.extension.en.petrotechsociety�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.petrotechsociety-v1.4.51.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.petrotechsociety.png"1.4(321.4.518BA�񄂆��#Petrotechsocietyen" https://www.petrotechsociety.org
�
Philia Scans,eu.kanade.tachiyomi.extension.en.philiascans�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.philiascans-v1.4.58.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.philiascans.png"1.4(:21.4.58B5�������KPhilia Scansen"https://philiascans.org
�
FlameScans.lol+eu.kanade.tachiyomi.extension.en.plutoscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.plutoscans-v1.4.52.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.plutoscans.png"1.4(421.4.52B6�������FlameScans.lolen"https://flamescans.lol
�
Rackus(eu.kanade.tachiyomi.extension.en.pmscans�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.pmscans-v1.4.39.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.pmscans.png"1.4('21.4.39B/����л��Rackusen"https://rackusreads.com
�
	PornComix*eu.kanade.tachiyomi.extension.en.porncomix�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.porncomix-v1.4.49.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.porncomix.png"1.4(121.4.498B4����ؙ��[	PornComixen"https://bestporncomix.com
�
Qi Scans(eu.kanade.tachiyomi.extension.en.qiscans�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.qiscans-v1.4.26.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.qiscans.png"1.4(21.4.26B,��Җ���PQiScansen"https://qimanga.com
�
Questionable Content4eu.kanade.tachiyomi.extension.en.questionablecontent�
phttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.questionablecontent-v1.4.10.apk}https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.questionablecontent.png"1.4(
21.4.10BI�ۈ�����MQuestionable Contenten"#https://www.questionablecontent.net
�

Rage Scans*eu.kanade.tachiyomi.extension.en.ragescans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.ragescans-v1.4.33.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ragescans.png"1.4(!21.4.33B1��������x
Rage Scansen"https://ragescans.com
�
Randowiz)eu.kanade.tachiyomi.extension.en.randowiz�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.randowiz-v1.4.2.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.randowiz.png"1.4(21.4.2B.݇�ײ���Randowizen"https://randowis.com
�
Raven Scans+eu.kanade.tachiyomi.extension.en.ravenscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.ravenscans-v1.4.34.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ravenscans.png"1.4("21.4.348B3�����ˀ�GRaven Scansen"https://ravenscans.org
�
Razure'eu.kanade.tachiyomi.extension.en.razure�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.razure-v1.4.32.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.razure.png"1.4( 21.4.32B*׌������)Razureen"https://razure.org
�
RD Scans(eu.kanade.tachiyomi.extension.en.rdscans�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.rdscans-v1.4.51.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rdscans.png"1.4(321.4.51B-��������"RD Scansen"https://rdscans.com
�
ReadAllComics1eu.kanade.tachiyomi.extension.en.readallcomicscom�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readallcomicscom-v1.4.8.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readallcomicscom.png"1.4(21.4.8B7�݊ʨ�gReadAllComicsen"https://readallcomics.com
�
-Read Attack on Titan Shingeki no Kyojin MangaGeu.kanade.tachiyomi.extension.en.readattackontitanshingekinokyojinmanga�
�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readattackontitanshingekinokyojinmanga-v1.4.13.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readattackontitanshingekinokyojinmanga.png"1.4(21.4.13BW촀�ꏥ�{-Read Attack on Titan Shingeki no Kyojin Mangaen"https://ww11.readsnk.com
�
Read Berserk Manga1eu.kanade.tachiyomi.extension.en.readberserkmanga�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readberserkmanga-v1.4.8.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readberserkmanga.png"1.4(21.4.8B;�����ۯ�DRead Berserk Mangaen"https://readberserk.com
�
Read Black Clover Manga Online;eu.kanade.tachiyomi.extension.en.readblackclovermangaonline�
vhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readblackclovermangaonline-v1.4.8.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readblackclovermangaonline.png"1.4(21.4.8BP��ף�̫�ZRead Black Clover Manga Onlineen" https://ww10.readblackclover.com
�
1Read Boku no Hero Academia My Hero Academia MangaJeu.kanade.tachiyomi.extension.en.readbokunoheroacademiamyheroacademiamanga�
�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readbokunoheroacademiamyheroacademiamanga-v1.4.10.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readbokunoheroacademiamyheroacademiamanga.png"1.4(
21.4.10B[��ܢ���D1Read Boku no Hero Academia My Hero Academia Mangaen"https://ww10.readmha.com
�
Read Chainsaw Man Manga Online;eu.kanade.tachiyomi.extension.en.readchainsawmanmangaonline�
vhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readchainsawmanmangaonline-v1.4.9.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readchainsawmanmangaonline.png"1.4(	21.4.98BO�ӆ��ʢ�VRead Chainsaw Man Manga Onlineen"https://ww5.readchainsawman.com
�
ReadComicOnline0eu.kanade.tachiyomi.extension.en.readcomiconline�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readcomiconline-v1.4.43.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readcomiconline.png"1.4(+21.4.43B7��������oReadComicOnlineen"https://rcostation.xyz
�
Read Comics Online1eu.kanade.tachiyomi.extension.en.readcomicsonline�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readcomicsonline-v1.4.14.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readcomicsonline.png"1.4(21.4.14B?�����ɘ�cRead Comics Onlineen"https://readcomicsonline.ru
�
)Read Fairy Tail & Edens Zero Manga OnlineBeu.kanade.tachiyomi.extension.en.readfairytailedenszeromangaonline�
}https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readfairytailedenszeromangaonline-v1.4.9.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readfairytailedenszeromangaonline.png"1.4(	21.4.9BX������)Read Fairy Tail & Edens Zero Manga Onlineen"https://ww8.readfairytail.com
�
 Read Jujutsu Kaisen Manga Online=eu.kanade.tachiyomi.extension.en.readjujutsukaisenmangaonline�
xhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readjujutsukaisenmangaonline-v1.4.9.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readjujutsukaisenmangaonline.png"1.4(	21.4.9BS������� Read Jujutsu Kaisen Manga Onlineen"!https://ww5.readjujutsukaisen.com
�
Read Kingdom Manga Online7eu.kanade.tachiyomi.extension.en.readkingdommangaonline�
rhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readkingdommangaonline-v1.4.8.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readkingdommangaonline.png"1.4(21.4.8BF��������nRead Kingdom Manga Onlineen"https://ww5.readkingdom.com
�
1Read Nanatsu no Taizai 7 Deadly Sins Manga OnlineJeu.kanade.tachiyomi.extension.en.readnanatsunotaizai7deadlysinsmangaonline�
�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readnanatsunotaizai7deadlysinsmangaonline-v1.4.10.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readnanatsunotaizai7deadlysinsmangaonline.png"1.4(
21.4.10Bb��������61Read Nanatsu no Taizai 7 Deadly Sins Manga Onlineen"https://ww7.read7deadlysins.com
�
)Read Naruto Boruto Samurai 8 Manga OnlineDeu.kanade.tachiyomi.extension.en.readnarutoborutosamurai8mangaonline�
https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readnarutoborutosamurai8mangaonline-v1.4.9.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readnarutoborutosamurai8mangaonline.png"1.4(	21.4.9BVȼ���΅�9)Read Naruto Boruto Samurai 8 Manga Onlineen"https://ww11.readnaruto.com
�
Read One Piece Manga Online8eu.kanade.tachiyomi.extension.en.readonepiecemangaonline�
shttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readonepiecemangaonline-v1.4.8.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readonepiecemangaonline.png"1.4(21.4.8BJ�ͅ�Ӫ��Read One Piece Manga Onlineen"https://ww12.readonepiece.com
�
Read One-Punch Man Manga Online>eu.kanade.tachiyomi.extension.en.readonepunchmanmangaonlinetwo�
yhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readonepunchmanmangaonlinetwo-v1.4.8.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readonepunchmanmangaonlinetwo.png"1.4(21.4.8BH��欆��rRead One-Punch Man Manga Onlineen"https://ww6.readopm.com
�
&Read Solo Leveling Manga Manhwa OnlineBeu.kanade.tachiyomi.extension.en.readsololevelingmangamanhwaonline�
~https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readsololevelingmangamanhwaonline-v1.4.10.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readsololevelingmangamanhwaonline.png"1.4(
21.4.10BX�����讉&Read Solo Leveling Manga Manhwa Onlineen" https://ww3.readsololeveling.org
�
.Read Tokyo Ghoul Re & Tokyo Ghoul Manga OnlineFeu.kanade.tachiyomi.extension.en.readtokyoghoulretokyoghoulmangaonline�
�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readtokyoghoulretokyoghoulmangaonline-v1.4.11.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readtokyoghoulretokyoghoulmangaonline.png"1.4(21.4.11B]˖������Y.Read Tokyo Ghoul Re & Tokyo Ghoul Manga Onlineen"https://ww11.tokyoghoulre.com
�
Read Vagabond Manga2eu.kanade.tachiyomi.extension.en.readvagabondmanga�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.readvagabondmanga-v1.4.1.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.readvagabondmanga.png"1.4(21.4.1B>��������IRead Vagabond Mangaen"https://readbagabondo.com
�
Real Life Comics/eu.kanade.tachiyomi.extension.en.reallifecomics�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.reallifecomics-v1.4.3.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.reallifecomics.png"1.4(21.4.3B<�������CReal Life Comicsen"https://reallifecomics.com
�
ReiManga)eu.kanade.tachiyomi.extension.en.reimanga�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.reimanga-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.reimanga.png"1.4(21.4.18B.��������NReiMangaen"https://reimanga.com
�
	Renascans*eu.kanade.tachiyomi.extension.en.renascans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.renascans-v1.4.23.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.renascans.png"1.4(21.4.23B0��ۗ����/	Renascansen"https://renascans.net
�

Rest Scans*eu.kanade.tachiyomi.extension.en.restscans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.restscans-v1.4.32.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.restscans.png"1.4( 21.4.328B1ϑ������7
Rest Scansen"https://restscans.com
�
Revival Scans-eu.kanade.tachiyomi.extension.en.revivalscans�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.revivalscans-v1.4.1.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.revivalscans.png"1.4(21.4.18B;���Ż´_Revival Scansen"https://www.revivalscans.com
�
Rinko Comics,eu.kanade.tachiyomi.extension.en.rinkocomics�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.rinkocomics-v1.4.2.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rinkocomics.png"1.4(21.4.2B5���΂��DRinko Comicsen"https://rinkocomics.com
�
RitharScans,eu.kanade.tachiyomi.extension.en.ritharscans�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.ritharscans-v1.4.23.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ritharscans.png"1.4(21.4.23B4�؃�����rRitharScansen"https://ritharscans.com
�

Rizz Comic*eu.kanade.tachiyomi.extension.en.rizzcomic�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.rizzcomic-v1.4.45.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rizzcomic.png"1.4(-21.4.45B2�����*
Rizz Comicen"https://rizzfables.com
�
Rizz Comic (unoriginal)4eu.kanade.tachiyomi.extension.en.rizzcomicunoriginal�
phttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.rizzcomicunoriginal-v1.4.32.apk}https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rizzcomicunoriginal.png"1.4( 21.4.32B>�㖌߁��|Rizz Comic (unoriginal)en"https://rizzcomic.com
�
RokariComics-eu.kanade.tachiyomi.extension.en.rokaricomics�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.rokaricomics-v1.4.34.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rokaricomics.png"1.4("21.4.34B6䂴��RokariComicsen"https://rokaricomics.com
�

Rolia Scan*eu.kanade.tachiyomi.extension.en.roliascan�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.roliascan-v1.4.8.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.roliascan.png"1.4(21.4.8B1�����/
Rolia Scanen"https://roliascan.com
�
Rose Squad Scans/eu.kanade.tachiyomi.extension.en.rosesquadscans�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.rosesquadscans-v1.4.52.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.rosesquadscans.png"1.4(421.4.528BF�����ޛ�KRose Squad Scansen"$https://rosesquadscans.aishiteru.org
�
Ryumanga)eu.kanade.tachiyomi.extension.en.ryumanga�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.ryumanga-v1.4.20.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.ryumanga.png"1.4(21.4.20B.݃�����@Ryumangaen"https://ryumanga.org
�
S2Manga(eu.kanade.tachiyomi.extension.en.s2manga�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.s2manga-v1.4.55.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.s2manga.png"1.4(721.4.558B+����ϼ��CS2Mangaen"https://s2read.com
�
Sabrina Online.eu.kanade.tachiyomi.extension.en.sabrinaonline�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.sabrinaonline-v1.4.1.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sabrinaonline.png"1.4(21.4.1B>��������Sabrina Onlineen"https://www.sabrina-online.com
�

SACACHISPA+eu.kanade.tachiyomi.extension.en.sacachispa�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.sacachispa-v1.4.1.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sacachispa.png"1.4(21.4.18B3�������
SACACHISPAen"https://sacachispa.site
�

Sana Scans*eu.kanade.tachiyomi.extension.en.sanascans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.sanascans-v1.4.23.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sanascans.png"1.4(21.4.23B1����ꔆ�
Sana Scansen"https://sanascans.com
�
!Saturday Morning Breakfast Comics?eu.kanade.tachiyomi.extension.en.saturdaymorningbreakfastcomics�
zhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.saturdaymorningbreakfastcomics-v1.4.2.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.saturdaymorningbreakfastcomics.png"1.4(21.4.2BJɴ����Ԑ*!Saturday Morning Breakfast Comicsen"https://smbc-comics.com
�
ScansGG(eu.kanade.tachiyomi.extension.en.scansgg�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.scansgg-v1.4.1.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.scansgg.png"1.4(21.4.18B)��ҧ���SScansGGen"https://scans.gg
�
Schlock Mercenary1eu.kanade.tachiyomi.extension.en.schlockmercenary�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.schlockmercenary-v1.4.2.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.schlockmercenary.png"1.4(21.4.2BC鞙�����ASchlock Mercenaryen" https://www.schlockmercenary.com
�
Setsu Scans+eu.kanade.tachiyomi.extension.en.setsuscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.setsuscans-v1.4.54.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.setsuscans.png"1.4(621.4.54B3���ޟ��vSetsu Scansen"https://setsuscans.com
�
Shiba Manga+eu.kanade.tachiyomi.extension.en.shibamanga�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.shibamanga-v1.4.51.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.shibamanga.png"1.4(321.4.518B3�����"Shiba Mangaen"https://shibamanga.com
�
Violet Scans+eu.kanade.tachiyomi.extension.en.shojoscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.shojoscans-v1.4.35.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.shojoscans.png"1.4(#21.4.35B5���Μ���}Violet Scansen"https://violetscans.org
�
Siren Scans+eu.kanade.tachiyomi.extension.en.sirenscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.sirenscans-v1.4.20.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sirenscans.png"1.4(21.4.20B3���񲡞�PSiren Scansen"https://sirenscans.com
�
	Sky Manga)eu.kanade.tachiyomi.extension.en.skymanga�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.skymanga-v1.4.33.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.skymanga.png"1.4(!21.4.338B0��������-	Sky Mangaen"https://skymanga.work
�
Sleepy Translations3eu.kanade.tachiyomi.extension.en.sleepytranslations�
ohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.sleepytranslations-v1.4.52.apk|https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sleepytranslations.png"1.4(421.4.52BC�����OSleepy Translationsen"https://sleepytranslations.com
�
Solar and Sundry/eu.kanade.tachiyomi.extension.en.solarandsundry�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.solarandsundry-v1.4.2.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.solarandsundry.png"1.4(21.4.2B9�欮�ٹ�dSolar and Sundryen"https://sas-api.fly.dev
�
Spmanhwa)eu.kanade.tachiyomi.extension.en.spmanhwa�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.spmanhwa-v1.4.51.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.spmanhwa.png"1.4(321.4.51B1�ᦼ���ASpmanhwaen"https://spmanhwa.online
�
SpyFakku)eu.kanade.tachiyomi.extension.en.spyfakku�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.spyfakku-v1.4.15.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.spyfakku.png"1.4(21.4.158B,��ܰ��ŉVSpyFakkuen"https://hentalk.pw
�

StoneScape+eu.kanade.tachiyomi.extension.en.stonescape�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.stonescape-v1.4.49.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.stonescape.png"1.4(121.4.49B2����탐�R
StoneScapeen"https://stonescape.xyz
�
Sunshine Butterfly Scans7eu.kanade.tachiyomi.extension.en.sunshinebutterflyscans�
shttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.sunshinebutterflyscans-v1.4.39.apk�https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.sunshinebutterflyscans.png"1.4('21.4.398B;�䟰����Sunshine Butterfly Scansen"https://wings.sbs
�

SUPER MEGA*eu.kanade.tachiyomi.extension.en.supermega�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.supermega-v1.4.4.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.supermega.png"1.4(21.4.4B;��Ρݽ��m
SUPER MEGAen"https://www.supermegacomics.com
�

Genz Toons+eu.kanade.tachiyomi.extension.en.suryascans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.suryascans-v1.4.53.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.suryascans.png"1.4(521.4.53B1��ǹ����
Genz Toonsen"https://genztoons.org
�
Swords Comic,eu.kanade.tachiyomi.extension.en.swordscomic�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.swordscomic-v1.4.5.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.swordscomic.png"1.4(21.4.5B5����ײ��8Swords Comicen"https://swordscomic.com
�
Tapas)eu.kanade.tachiyomi.extension.en.tapastic�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.tapastic-v1.4.24.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tapastic.png"1.4(21.4.248B'��ͣ�ӛ�MTapasen"https://tapas.io
�
	TCB Scans)eu.kanade.tachiyomi.extension.en.tcbscans�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.tcbscans-v1.4.12.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tcbscans.png"1.4(21.4.12B:�������	TCB Scansen"https://tcbonepiecechapters.com
�
TCB Scans (Unoriginal)3eu.kanade.tachiyomi.extension.en.tcbscansunoriginal�
ohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.tcbscansunoriginal-v1.4.32.apk|https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tcbscansunoriginal.png"1.4( 21.4.32BKΓц����*TCB Scans (Unoriginal)en"#https://tcbscanonepiecechapters.com
�
Team Shadowi,eu.kanade.tachiyomi.extension.en.teamshadowi�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.teamshadowi-v1.4.1.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.teamshadowi.png"1.4(21.4.18B:������´Team Shadowien"https://www.team-shadowi.com
�
Temple Scan+eu.kanade.tachiyomi.extension.en.templescan�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.templescan-v1.4.49.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.templescan.png"1.4(121.4.498B4������:Temple Scanen"https://templetoons.com
�
	The Blank)eu.kanade.tachiyomi.extension.en.theblank�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.theblank-v1.4.56.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.theblank.png"1.4(821.4.568B/ϳ����פh	The Blanken"https://theblank.net
�
The Duck Webcomics1eu.kanade.tachiyomi.extension.en.theduckwebcomics�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.theduckwebcomics-v1.4.3.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.theduckwebcomics.png"1.4(21.4.38BD�����JThe Duck Webcomicsen" https://www.theduckwebcomics.com
�
The Property of Hate2eu.kanade.tachiyomi.extension.en.thepropertyofhate�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.thepropertyofhate-v1.4.5.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.thepropertyofhate.png"1.4(21.4.5B>����͞�eThe Property of Hateen"https://jolleycomics.com
�
TimelessToons.eu.kanade.tachiyomi.extension.en.timelesstoons�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.timelesstoons-v1.4.20.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.timelesstoons.png"1.4(21.4.20B8�����׫�}TimelessToonsen"https://timelesstoons.org
�

TodayManga+eu.kanade.tachiyomi.extension.en.todaymanga�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.todaymanga-v1.4.3.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.todaymanga.png"1.4(21.4.38B2���ˋ���
TodayMangaen"https://todaymanga.com
�
Toon18'eu.kanade.tachiyomi.extension.en.toon18�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.toon18-v1.4.51.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toon18.png"1.4(321.4.518B)��������uToon18en"https://toon18.to
�
ToonGod(eu.kanade.tachiyomi.extension.en.toongod�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.toongod-v1.4.56.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toongod.png"1.4(821.4.568B0����ʚ��ToonGoden"https://www.toongod.org
�
Toonily(eu.kanade.tachiyomi.extension.en.toonily�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.toonily-v1.4.65.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonily.png"1.4(A21.4.658B,��˾��HToonilyen"https://toonily.com
�

Toonily.me*eu.kanade.tachiyomi.extension.en.toonilyme�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.toonilyme-v1.4.24.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonilyme.png"1.4(21.4.248B.Ȣ������
Toonily.meen"https://toonily.me
�
	TooniTube*eu.kanade.tachiyomi.extension.en.toonitube�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.toonitube-v1.4.24.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonitube.png"1.4(21.4.248B0���ú�q	TooniTubeen"https://toonitube.com
�
Toonizy(eu.kanade.tachiyomi.extension.en.toonizy�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.toonizy-v1.4.51.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.toonizy.png"1.4(321.4.518B,�݂۫�KToonizyen"https://toonizy.com
�

Top Manhua*eu.kanade.tachiyomi.extension.en.topmanhua�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.topmanhua-v1.4.58.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.topmanhua.png"1.4(:21.4.588B0��������
Top Manhuaen"https://mangatop.org
�
TopManhua.fan-eu.kanade.tachiyomi.extension.en.topmanhuafan�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.topmanhuafan-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.topmanhuafan.png"1.4(321.4.518B8��������WTopManhua.fanen"https://www.topmanhua.fan
�
TopManhua.net-eu.kanade.tachiyomi.extension.en.topmanhuanet�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.topmanhuanet-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.topmanhuanet.png"1.4(321.4.518B4Ѧ䬒׍�YTopManhua.neten"https://topmanhua.net
�
TritiniaScans.eu.kanade.tachiyomi.extension.en.tritiniascans�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.tritiniascans-v1.4.55.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.tritiniascans.png"1.4(721.4.55B3��砫���STritiniaScansen"https://tritinia.org
�
Utoon&eu.kanade.tachiyomi.extension.en.utoon�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.utoon-v1.4.56.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.utoon.png"1.4(821.4.56B(��ʑ����2Utoonen"https://utoon.net
�
Valir Scans+eu.kanade.tachiyomi.extension.en.valirscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.valirscans-v1.4.22.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.valirscans.png"1.4(21.4.22B3�������uValir Scansen"https://valirscans.org
�
Vanilla Scans-eu.kanade.tachiyomi.extension.en.vanillascans�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.vanillascans-v1.4.23.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vanillascans.png"1.4(21.4.23B7���Ɵî�Vanilla Scansen"https://vanillascans.org
�
vgperson)eu.kanade.tachiyomi.extension.en.vgperson�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.vgperson-v1.4.7.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vgperson.png"1.4(21.4.7BD���Ǿ�yvgpersonen"*https://vgperson.com/other/mangaviewer.php
�
VIZ.eu.kanade.tachiyomi.extension.en.vizshonenjump�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.vizshonenjump-v1.4.25.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vizshonenjump.png"1.4(21.4.25B4ô������%VIZ Shonen Jumpen"https://www.viz.comB.�´��)	VIZ Mangaen"https://www.viz.com
�
Voyce.Me(eu.kanade.tachiyomi.extension.en.voyceme�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.voyceme-v1.4.6.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.voyceme.png"1.4(21.4.6B-�Ԉ�����BVoyceMeen"https://www.voyce.me
�
	VyvyManga*eu.kanade.tachiyomi.extension.en.vyvymanga�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.vyvymanga-v1.4.40.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vyvymanga.png"1.4((21.4.408B.٣֐Ӕ��`	VyvyMangaen"https://vymanga.net
�
VyvyManga.org-eu.kanade.tachiyomi.extension.en.vyvymangaorg�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.vyvymangaorg-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.vyvymangaorg.png"1.4(321.4.518B4㹕�����!VyvyManga.orgen"https://vyvymanga.org
�
War For Rayuba-eu.kanade.tachiyomi.extension.en.warforrayuba�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.warforrayuba-v1.4.3.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.warforrayuba.png"1.4(21.4.3BE��볱��War For Rayubaen"%https://xrabohrok.github.io/WarMap/#/
�

KokoMangas,eu.kanade.tachiyomi.extension.en.wearehunger�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.wearehunger-v1.4.53.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.wearehunger.png"1.4(521.4.538B1���磷�h
KokoMangasen"https://kokomangas.com
�
	Webcomics*eu.kanade.tachiyomi.extension.en.webcomics�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.webcomics-v1.4.10.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webcomics.png"1.4(
21.4.10B3��������h	Webcomicsen"https://webcomicsapp.com
�
Webdex Scans,eu.kanade.tachiyomi.extension.en.webdexscans�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.webdexscans-v1.4.52.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webdexscans.png"1.4(421.4.52B5��������wWebdex Scansen"https://webdexscans.com
�
WebNovel)eu.kanade.tachiyomi.extension.en.webnovel�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.webnovel-v1.4.13.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webnovel.png"1.4(21.4.13B2�������8WebNovelen"https://www.webnovel.com
�
WebtoonScan,eu.kanade.tachiyomi.extension.en.webtoonscan�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.webtoonscan-v1.4.51.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webtoonscan.png"1.4(321.4.518B4я������*WebtoonScanen"https://webtoonscan.com
�

WebtoonXYZ+eu.kanade.tachiyomi.extension.en.webtoonxyz�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.webtoonxyz-v1.4.55.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.webtoonxyz.png"1.4(721.4.558B3�������]
WebtoonXYZen"https://www.webtoon.xyz
�
Weeb Central,eu.kanade.tachiyomi.extension.en.weebcentral�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.weebcentral-v1.4.22.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.weebcentral.png"1.4(21.4.228B5ú�̬ӹ�Weeb Centralen"https://weebcentral.com
�
Whale Manga+eu.kanade.tachiyomi.extension.en.whalemanga�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.whalemanga-v1.4.51.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.whalemanga.png"1.4(321.4.518B2ᰎ�ՠ��N
WhaleMangaen"https://whalemanga.com
�

WitchScans+eu.kanade.tachiyomi.extension.en.witchscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.witchscans-v1.4.32.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.witchscans.png"1.4( 21.4.32B2֥��뤟�v
WitchScansen"https://witchscans.com
�
WoopRead)eu.kanade.tachiyomi.extension.en.woopread�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.woopread-v1.4.52.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.woopread.png"1.4(421.4.52B.��㡓���{WoopReaden"https://woopread.com
�
Writer Scans,eu.kanade.tachiyomi.extension.en.writerscans�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.writerscans-v1.4.20.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.writerscans.png"1.4(21.4.20B5��ҳ����Writer Scansen"https://writerscans.com
�

WuxiaWorld+eu.kanade.tachiyomi.extension.en.wuxiaworld�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.wuxiaworld-v1.4.52.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.wuxiaworld.png"1.4(421.4.52B3���۠���Z
WuxiaWorlden"https://wuxiaworld.site
�
XlecX&eu.kanade.tachiyomi.extension.en.xlecx�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.xlecx-v1.4.1.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xlecx.png"1.4(21.4.18B(ǆ�����3XlecXen"https://xlecx.one
�
XoManga(eu.kanade.tachiyomi.extension.en.xomanga�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.xomanga-v1.4.1.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xomanga.png"1.4(21.4.18B1��ﳽ�ؙEXoMangaen"https://www.xomanga.site
�
XOXO Comics+eu.kanade.tachiyomi.extension.en.xoxocomics�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.xoxocomics-v1.4.13.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xoxocomics.png"1.4(21.4.13B2�����Χ�!XOXO Comicsen"https://xoxocomic.com
�
Xscans'eu.kanade.tachiyomi.extension.en.xscans�
bhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.xscans-v1.4.1.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.xscans.png"1.4(21.4.1B+�҃���eXscansen"https://xscans.site
�
YakshaComics-eu.kanade.tachiyomi.extension.en.yakshacomics�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.yakshacomics-v1.4.53.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yakshacomics.png"1.4(521.4.53B6��������CYakshaComicsen"https://yakshacomics.com
�
YaoiHot(eu.kanade.tachiyomi.extension.en.yaoihot�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.yaoihot-v1.4.1.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoihot.png"1.4(21.4.18B,��������&YaoiHoten"https://yaoihot.com
�
Yaoihub(eu.kanade.tachiyomi.extension.en.yaoihub�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.yaoihub-v1.4.53.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoihub.png"1.4(521.4.538B,��ʸ��]Yaoihuben"https://yaoihub.net
�
YaoiScan)eu.kanade.tachiyomi.extension.en.yaoiscan�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.yaoiscan-v1.4.51.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoiscan.png"1.4(321.4.518B.��Ӹ����=YaoiScanen"https://yaoiscan.com
�
YaoiToon)eu.kanade.tachiyomi.extension.en.yaoitoon�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.yaoitoon-v1.4.48.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yaoitoon.png"1.4(021.4.488B.謈�����QYaoiToonen"https://yaoitoon.net
�
Yorai&eu.kanade.tachiyomi.extension.en.yorai�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.yorai-v1.4.2.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.yorai.png"1.4(21.4.2B'����Ϩ�"Yoraien"https://yorai.io
�
	Zazamanga*eu.kanade.tachiyomi.extension.en.zazamanga�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.zazamanga-v1.4.52.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zazamanga.png"1.4(421.4.528B4���ּװ�	Zazamangaen"https://www.zazamanga.com
�
ZinChanManga-eu.kanade.tachiyomi.extension.en.zinchanmanga�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.zinchanmanga-v1.4.54.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinchanmanga.png"1.4(621.4.548B7�ɿ�����ZinChanMangaen"https://zinchangmanga.net
�
ZinChanManga.com0eu.kanade.tachiyomi.extension.en.zinchanmangacom�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.zinchanmangacom-v1.4.54.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinchanmangacom.png"1.4(621.4.548B;՝������uZinChanManga.comen"https://zinchangmanga.net
�
Zinmanga)eu.kanade.tachiyomi.extension.en.zinmanga�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.zinmanga-v1.4.54.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinmanga.png"1.4(621.4.548B.�����ʐSZinmangaen"https://mangazin.org
�
Zinmanga.net,eu.kanade.tachiyomi.extension.en.zinmanganet�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-en.zinmanganet-v1.4.51.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.en.zinmanganet.png"1.4(321.4.51B2���⢸��Zinmanga.neten"https://zinmanga.net
�
AKAYA&eu.kanade.tachiyomi.extension.es.akaya�
ahttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.akaya-v1.4.3.apkohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.akaya.png"1.4(21.4.38B'���Ջ�ϧ	AKAYAes"https://akaya.io
�
AnzManga)eu.kanade.tachiyomi.extension.es.anzmanga�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.anzmanga-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.anzmanga.png"1.4(21.4.1B4������ޫfAnzMangaes"https://www.anzmanga25.com
�
ApollComics,eu.kanade.tachiyomi.extension.es.apollcomics�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.apollcomics-v1.4.54.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.apollcomics.png"1.4(621.4.548B3��������*ApollComicses"https://apollcomics.es
�

Asia Lotus*eu.kanade.tachiyomi.extension.es.asialotus�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.asialotus-v1.4.33.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.asialotus.png"1.4(!21.4.338B2��������2
Asia Lotuses"https://asialotuss.com
�
BarManga)eu.kanade.tachiyomi.extension.es.barmanga�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.barmanga-v1.4.62.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.barmanga.png"1.4(>21.4.628B2��������BarMangaes"https://archiviumbar.com
�
Bega Translation0eu.kanade.tachiyomi.extension.es.begatranslation�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.begatranslation-v1.4.54.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.begatranslation.png"1.4(621.4.548B=��۰р��]Bega Translationes"https://begatranslation.com
�
Biblio Panda,eu.kanade.tachiyomi.extension.es.bibliopanda�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.bibliopanda-v1.4.54.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.bibliopanda.png"1.4(621.4.54B5�ґ��rBiblio Pandaes"https://bibliopanda.com
�
Bloom Scans+eu.kanade.tachiyomi.extension.es.bloomscans�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.bloomscans-v1.4.34.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.bloomscans.png"1.4("21.4.348B3�����ա�$Bloom Scanses"https://bloomscans.com
�
BokugenTranslation3eu.kanade.tachiyomi.extension.es.bokugentranslation�
ohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.bokugentranslation-v1.4.50.apk|https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.bokugentranslation.png"1.4(221.4.50B9Ѵ�Ø���BokugenTranslationes"https://bokugents.com
�
Bymichi Scan,eu.kanade.tachiyomi.extension.es.bymichiscan�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.bymichiscan-v1.4.33.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.bymichiscan.png"1.4(!21.4.338B3����­��=Bymichi Scanes"https://bymichiby.com
�
CapibaraTraductor2eu.kanade.tachiyomi.extension.es.capibaratraductor�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.capibaratraductor-v1.4.1.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.capibaratraductor.png"1.4(21.4.18B@����ϱǤ.CapibaraTraductores"https://capibaratraductor.com
�
Catharsis World/eu.kanade.tachiyomi.extension.es.catharsisworld�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.catharsisworld-v1.4.65.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.catharsisworld.png"1.4(A21.4.658BC��������'Catharsis Worldes""https://catharsisworld.dig-it.info
�
Catoons+eu.kanade.tachiyomi.extension.es.catmanhwas�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.catmanhwas-v1.4.53.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.catmanhwas.png"1.4(521.4.538B,���Ċ��Catoonses"https://newcat1.xyz
�
Celestial Moon.eu.kanade.tachiyomi.extension.es.celestialmoon�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.celestialmoon-v1.4.33.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.celestialmoon.png"1.4(!21.4.338B<��������kCelestial Moones"https://celestialmoonscan.es
�
Cerberus Series/eu.kanade.tachiyomi.extension.es.cerberusseries�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.cerberusseries-v1.4.33.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.cerberusseries.png"1.4(!21.4.33B;��������Cerberus Serieses"https://legionscans.com/wp
�
ChoChoX(eu.kanade.tachiyomi.extension.es.chochox�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.chochox-v1.4.3.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.chochox.png"1.4(21.4.38B,�������ChoChoXes"https://chochox.com
�
Code Arc Mangas(eu.kanade.tachiyomi.extension.es.codearc�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.codearc-v1.4.3.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.codearc.png"1.4(21.4.38BG��������LCode Arc Mangases"&https://mangas.codearctraducciones.com
�

Codex Zero*eu.kanade.tachiyomi.extension.es.codexzero�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.codexzero-v1.4.53.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.codexzero.png"1.4(521.4.53B6��圁ɕK
Codex Zeroes"https://codex.readkisho.me
�
Colorcito Scan.eu.kanade.tachiyomi.extension.es.colorcitoscan�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.colorcitoscan-v1.4.3.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.colorcitoscan.png"1.4(21.4.38B9�ׂɎ���Colorcito Scanes"https://colorcitoscan.com
�
Dark Room Fansub/eu.kanade.tachiyomi.extension.es.darkroomfansub�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.darkroomfansub-v1.4.15.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.darkroomfansub.png"1.4(21.4.158BL��������&Dark Room Fansubes"*https://lector-darkroomfansub.blogspot.com
�
Dat-Gar Scan1eu.kanade.tachiyomi.extension.es.datgarscanlation�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.datgarscanlation-v1.4.14.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.datgarscanlation.png"1.4(21.4.14BC잜�����Dat-Gar Scanes"%https://datgarscanlation.blogspot.com
�
DoujinHentai-eu.kanade.tachiyomi.extension.es.doujinhentai�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.doujinhentai-v1.4.50.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.doujinhentai.png"1.4(221.4.508B6����ɵ��6DoujinHentaies"https://doujinhentai.net
�
DoujinsHell,eu.kanade.tachiyomi.extension.es.doujinshell�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.doujinshell-v1.4.52.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.doujinshell.png"1.4(421.4.528B4����Մ��aDoujinsHelles"https://doujinshell.net
�
DragonTranslation.org5eu.kanade.tachiyomi.extension.es.dragontranslationorg�
qhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.dragontranslationorg-v1.4.52.apk~https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.dragontranslationorg.png"1.4(421.4.528BD��Ћ���@DragonTranslation.orges"https://dragontranslation.org
�
Dynasty(eu.kanade.tachiyomi.extension.es.dynasty�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.dynasty-v1.4.1.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.dynasty.png"1.4(21.4.18B-��䓐���Dynastyes"https://manhuako.net
�
Emperor Scan,eu.kanade.tachiyomi.extension.es.emperorscan�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.emperorscan-v1.4.67.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.emperorscan.png"1.4(C21.4.67B7���󅝊�?Emperor Scanes"https://imperiomanhua.com
�
EnchiladaScan.eu.kanade.tachiyomi.extension.es.enchiladascan�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.enchiladascan-v1.4.1.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.enchiladascan.png"1.4(21.4.1BK���߸���{EnchiladaScanes",https://enchiladascan.github.io/enchiladaweb
�
Es.Mi2Manga+eu.kanade.tachiyomi.extension.es.esmi2manga�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.esmi2manga-v1.4.52.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.esmi2manga.png"1.4(421.4.528B4��������Es.Mi2Mangaes"https://es.mi2manga.com
�
EternalMangas.eu.kanade.tachiyomi.extension.es.eternalmangas�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.eternalmangas-v1.4.25.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.eternalmangas.png"1.4(21.4.258B8�몬���EternalMangases"https://eternalmangas.org
�
Gistamis House.eu.kanade.tachiyomi.extension.es.gistamishouse�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.gistamishouse-v1.4.15.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.gistamishouse.png"1.4(21.4.158BH��ꦡ��Gistamis Housees"(https://gistamishousefansub.blogspot.com
�
Gremory Mangas.eu.kanade.tachiyomi.extension.es.gremorymangas�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.gremorymangas-v1.4.52.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.gremorymangas.png"1.4(421.4.52B<�މա���_Gremory Mangases"https://gremoryhistorias.org
�
Hades no Fansub.eu.kanade.tachiyomi.extension.es.hadesnofansub�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.hadesnofansub-v1.4.58.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.hadesnofansub.png"1.4(:21.4.588BB��ˇ߼��sHades no Fansubes"!https://lectorhades.latamtoon.com
�
Harem de Kira,eu.kanade.tachiyomi.extension.es.haremdekira�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.haremdekira-v1.4.54.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.haremdekira.png"1.4(621.4.548B6�ợ����Harem de Kiraes"https://kiraproject.lat
�
HeavenManga,eu.kanade.tachiyomi.extension.es.heavenmanga�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.heavenmanga-v1.4.9.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.heavenmanga.png"1.4(	21.4.98B4�䥸����HeavenMangaes"https://heavenmanga.com
�

HentaiHall+eu.kanade.tachiyomi.extension.es.hentaihall�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.hentaihall-v1.4.1.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.hentaihall.png"1.4(21.4.18B2߄���ӝ�u
HentaiHalles"https://hentaihall.com
�

HentaiMode+eu.kanade.tachiyomi.extension.es.hentaimode�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.hentaimode-v1.4.7.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.hentaimode.png"1.4(21.4.78B2ڽ����ΤH
HentaiModees"https://hentaimode.com
�
Hmangakyomi,eu.kanade.tachiyomi.extension.es.hmangakyomi�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.hmangakyomi-v1.4.32.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.hmangakyomi.png"1.4( 21.4.328B7�ʊ�����MHmangakyomies"https://hmangakyomi.online
�
House Of Otakus.eu.kanade.tachiyomi.extension.es.houseofotakus�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.houseofotakus-v1.4.51.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.houseofotakus.png"1.4(321.4.518B<������House Of Otakuses"https://houseofotakusv2.xyz
�
Ikigai Mangas-eu.kanade.tachiyomi.extension.es.ikigaimangas�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.ikigaimangas-v1.4.32.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.ikigaimangas.png"1.4( 21.4.328B@����̜݊1Ikigai Mangases"!https://zonaikigai.gamesview.shop
�
	Ikuhentai*eu.kanade.tachiyomi.extension.es.ikuhentai�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.ikuhentai-v1.4.4.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.ikuhentai.png"1.4(21.4.48B0������ہi	Ikuhentaies"https://ikuhentai.net
�
InfraFandub,eu.kanade.tachiyomi.extension.es.infrafandub�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.infrafandub-v1.4.54.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.infrafandub.png"1.4(621.4.54B4�����ߖ�MInfraFandubes"https://infrafandub.com
�
InManga(eu.kanade.tachiyomi.extension.es.inmanga�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.inmanga-v1.4.4.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.inmanga.png"1.4(21.4.4B,�Ό����`InMangaes"https://inmanga.com
�
Inmortal Scan-eu.kanade.tachiyomi.extension.es.inmortalscan�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.inmortalscan-v1.4.54.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.inmortalscan.png"1.4(621.4.54B7���Ѳ��{Inmortal Scanes"https://scanimnortal.com
�
InsanosScan,eu.kanade.tachiyomi.extension.es.insanosscan�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.insanosscan-v1.4.31.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.insanosscan.png"1.4(21.4.31B7��������IInsanosScanes"https://insanoslibrary.com
�
Inventario Oculto1eu.kanade.tachiyomi.extension.es.inventariooculto�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.inventariooculto-v1.4.51.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.inventariooculto.png"1.4(321.4.51B?���թ�ӺInventario Ocultoes"https://inventariooculto.com
�

Jeaz Scans*eu.kanade.tachiyomi.extension.es.jeazscans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.jeazscans-v1.4.67.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.jeazscans.png"1.4(C21.4.67B5������źp
Jeaz Scanses"https://lectorhub.j5z.xyz
�

Kazoku Den*eu.kanade.tachiyomi.extension.es.kazokuden�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.kazokuden-v1.4.51.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.kazokuden.png"1.4(321.4.51B5�ʹ����
Kazoku Denes"https://www.kazokuden.com
�
Koinobori Scan.eu.kanade.tachiyomi.extension.es.koinoboriscan�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.koinoboriscan-v1.4.40.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.koinoboriscan.png"1.4((21.4.408B4��������QKoinobori Scanes"https://visorkoi.com
�
Lector Asteria.eu.kanade.tachiyomi.extension.es.lectorasteria�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.lectorasteria-v1.4.3.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lectorasteria.png"1.4(21.4.38B9ױ�廀��	Lector Asteriaes"https://lectorasteria.com
�
	LectorJPG*eu.kanade.tachiyomi.extension.es.lectorjpg�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.lectorjpg-v1.4.50.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lectorjpg.png"1.4(221.4.508B/����Ľ��=	LectorJPGes"https://visorjpg.lat
�
LectorManga.lat/eu.kanade.tachiyomi.extension.es.lectormangalat�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.lectormangalat-v1.4.55.apkxhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lectormangalat.png"1.4(721.4.558B:߱�మȯ3LectorManga.lates"https://lectormangass.com
�
MangoLibreria.eu.kanade.tachiyomi.extension.es.lectormonline�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.lectormonline-v1.4.2.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lectormonline.png"1.4(21.4.28B8�ћ碚��:MangoLibreriaes"https://mangolibreria.com
�
LeerCapitulo-eu.kanade.tachiyomi.extension.es.leercapitulo�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.leercapitulo-v1.4.17.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.leercapitulo.png"1.4(21.4.17B9�ǧ�����NLeerCapituloes"https://www.leercapitulo.co
�
	LeerManga*eu.kanade.tachiyomi.extension.es.leermanga�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.leermanga-v1.4.52.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.leermanga.png"1.4(421.4.528B0±������.	LeerMangaes"https://leermanga.net
�
LeerMangaEsp-eu.kanade.tachiyomi.extension.es.leermangaesp�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.leermangaesp-v1.4.1.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.leermangaesp.png"1.4(21.4.18B6�׿��ّ�qLeerMangaEspes"https://leermangaesp.net
�
Lmtos+eu.kanade.tachiyomi.extension.es.lmtoonline�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.lmtoonline-v1.4.54.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lmtoonline.png"1.4(621.4.548B(�����匨kLmtoses"https://lmtos.net
�
	Lolivault*eu.kanade.tachiyomi.extension.es.lolivault�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.lolivault-v1.4.5.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lolivault.png"1.4(21.4.58B7�˒���	Lolivaultes"https://lector.lolivault.net
�
Luna Pieces+eu.kanade.tachiyomi.extension.es.lunapieces�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.lunapieces-v1.4.32.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.lunapieces.png"1.4( 21.4.328B9������	Luna Pieceses"https://lunapiecesfansub.com
�

Manga Crab*eu.kanade.tachiyomi.extension.es.mangacrab�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mangacrab-v1.4.74.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangacrab.png"1.4(J21.4.74B1�̙Û��U
Manga Crabes"https://mangacrab.org
�
MangaEsp)eu.kanade.tachiyomi.extension.es.mangaesp�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mangaesp-v1.4.33.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangaesp.png"1.4(!21.4.33B9Ĉ�����MangaEspes"https://mangaesp.topmanhuas.org
�
MangaLector,eu.kanade.tachiyomi.extension.es.mangalector�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mangalector-v1.4.51.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangalector.png"1.4(321.4.518B4�����˗�>MangaLectores"https://mangalector.com
�
MangaOni(eu.kanade.tachiyomi.extension.es.mangamx�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mangamx-v1.4.19.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangamx.png"1.4(21.4.198B/��͊����MangaOnies"https://manga-oni.com
�
Manga Romance-eu.kanade.tachiyomi.extension.es.mangaromance�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mangaromance-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangaromance.png"1.4(321.4.518B9���ң���5Manga Romancees"https://mangaromance19.com
�
Manga Mukai,eu.kanade.tachiyomi.extension.es.mangashiina�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mangashiina-v1.4.33.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangashiina.png"1.4(!21.4.338B3��������	Manga Mukaies"https://mangamukai.com
�
	Mangas.in)eu.kanade.tachiyomi.extension.es.mangasin�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mangasin-v1.4.21.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangasin.png"1.4(21.4.218B*ɰ�ӳ��.	Mangas.ines"https://m440.in
�
Mangas No Sekai.eu.kanade.tachiyomi.extension.es.mangasnosekai�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mangasnosekai-v1.4.70.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangasnosekai.png"1.4(F21.4.70B:�Ր�����Mangas No Sekaies"https://mangasnosekai.com
�
Manga TV(eu.kanade.tachiyomi.extension.es.mangatv�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mangatv-v1.4.35.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mangatv.png"1.4(#21.4.358B.ܥ����ڎd	Manga  TVes"https://mangatv.net
�
SamuraiScan-eu.kanade.tachiyomi.extension.es.manhuaonline�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.manhuaonline-v1.4.68.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.manhuaonline.png"1.4(D21.4.68B4��������OSamuraiScanes"https://samurai.j5z.xyz
�
Manhwa-Latino-eu.kanade.tachiyomi.extension.es.manhwalatino�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.manhwalatino-v1.4.62.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.manhwalatino.png"1.4(>21.4.628B8Ӭ����ʟ1Manhwa-Latinoes"https://manhwa-latino.com
�
ManhwaOnline-eu.kanade.tachiyomi.extension.es.manhwaonline�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.manhwaonline-v1.4.53.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.manhwaonline.png"1.4(521.4.538B7���繊��KManhwaOnlinees"https://manhwa-online.com
�
	ManhwaWeb*eu.kanade.tachiyomi.extension.es.manhwaweb�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.manhwaweb-v1.4.13.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.manhwaweb.png"1.4(21.4.138B0��������R	ManhwaWebes"https://manhwaweb.com
�
Manhwa Scan,eu.kanade.tachiyomi.extension.es.mantrazscan�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mantrazscan-v1.4.56.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mantrazscan.png"1.4(821.4.568B4žʋ����cManhwa Scanes"https://manhwascanx.lat
�
Marmota(eu.kanade.tachiyomi.extension.es.marmota�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.marmota-v1.4.51.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.marmota.png"1.4(321.4.51B+̆����RMarmotaes"https://marmota.me
�
Menudo-Fansub-eu.kanade.tachiyomi.extension.es.menudofansub�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.menudofansub-v1.4.6.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.menudofansub.png"1.4(21.4.6B<����ƪ��0Menudo-Fansubes"https://www.menudo-fansub.com
�
MHScans(eu.kanade.tachiyomi.extension.es.mhscans�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mhscans-v1.4.65.apkqhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mhscans.png"1.4(A21.4.65B,񬬮�냓-MHScanses"https://mhscans.com
�
Monopoly Scan-eu.kanade.tachiyomi.extension.es.monopolyscan�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.monopolyscan-v1.4.51.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.monopolyscan.png"1.4(321.4.51B9�������QMonopoly Scanes"https://monopolymanhua.com
�
Mundo Manhwa,eu.kanade.tachiyomi.extension.es.mundomanhwa�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.mundomanhwa-v1.4.51.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.mundomanhwa.png"1.4(321.4.518B5��֯����bMundo Manhwaes"https://mundomanhwa.com
�

Rncalation'eu.kanade.tachiyomi.extension.es.nartag�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.nartag-v1.4.59.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.nartag.png"1.4(;21.4.598B5�������)
Rncalationes"https://rncalation.online
�
	NekoScans*eu.kanade.tachiyomi.extension.es.nekoscans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.nekoscans-v1.4.40.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.nekoscans.png"1.4((21.4.408B2�������t	NekoScanses"https://nekoproject.org
�
NeoManga)eu.kanade.tachiyomi.extension.es.neomanga�
dhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.neomanga-v1.4.1.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.neomanga.png"1.4(21.4.1B5��������DNeoMangaes"https://www.neomanga.online
�
NexusScanlation0eu.kanade.tachiyomi.extension.es.nexusscanlation�
khttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.nexusscanlation-v1.4.4.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.nexusscanlation.png"1.4(21.4.48B<�Ղ�����8NexusScanlationes"https://nexusscanlation.com
�
Noblesse Translations5eu.kanade.tachiyomi.extension.es.noblessetranslations�
qhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.noblessetranslations-v1.4.58.apk~https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.noblessetranslations.png"1.4(:21.4.58BD���ۘ��GNoblesse Translationses"https://nobledicion.yoveo.xyz
�
Nova Manhwas+eu.kanade.tachiyomi.extension.es.novamanhwa�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.novamanhwa-v1.4.32.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.novamanhwa.png"1.4( 21.4.32B3���פ��%Nova Manhwases"https://novamanhwa.cc
�
Novato Scans,eu.kanade.tachiyomi.extension.es.novatoscans�
hhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.novatoscans-v1.4.14.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.novatoscans.png"1.4(21.4.14B9����˿�Novato Scanses"https://www.novatoscans.top
�
Olympus Scanlation2eu.kanade.tachiyomi.extension.es.olympusscanlation�
nhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.olympusscanlation-v1.4.20.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.olympusscanlation.png"1.4(21.4.20B:��긜��Olympus Scanlationes"https://olympusxyz.com
�

ONF MANGAS*eu.kanade.tachiyomi.extension.es.onfmangas�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.onfmangas-v1.4.6.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.onfmangas.png"1.4(21.4.68B1ȏ�ˠ���
ONF MANGASes"https://onfmangas.com
�
OrckuMangas,eu.kanade.tachiyomi.extension.es.orckumangas�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.orckumangas-v1.4.2.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.orckumangas.png"1.4(21.4.28B5��Ҫ��ϾOrcku Mangases"https://orckumangas.com
�
Platinum Lily Scan1eu.kanade.tachiyomi.extension.es.platinumlilyscan�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.platinumlilyscan-v1.4.1.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.platinumlilyscan.png"1.4(21.4.18B@��������RPlatinum Lily Scanes"https://platinumlilyscan.com
�
Plot Twist No Fansub2eu.kanade.tachiyomi.extension.es.plottwistnofansub�
nhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.plottwistnofansub-v1.4.14.apk{https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.plottwistnofansub.png"1.4(21.4.148B>�Ȼ�����`Plot Twist No Fansubes"https://plotnofansub.com
�
Ragnarok Scanlation3eu.kanade.tachiyomi.extension.es.ragnarokscanlation�
ohttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.ragnarokscanlation-v1.4.54.apk|https://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.ragnarokscanlation.png"1.4(621.4.54BC�э�����Ragnarok Scanlationes"https://ragnarokscanlation.org
�
Ragna Scans+eu.kanade.tachiyomi.extension.es.ragnascans�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.ragnascans-v1.4.2.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.ragnascans.png"1.4(21.4.2B9���ک���SRagna Scanses"https://lector.ragnascan.xyz
�

Raiki Scan*eu.kanade.tachiyomi.extension.es.raikiscan�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.raikiscan-v1.4.32.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.raikiscan.png"1.4( 21.4.32B1�������m
Raiki Scanes"https://raikiscan.com
�

RavenManga+eu.kanade.tachiyomi.extension.es.ravenmanga�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.ravenmanga-v1.4.7.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.ravenmanga.png"1.4(21.4.7B1�������	
RavenMangaes"https://raventard.xyz
�

RichtoScan+eu.kanade.tachiyomi.extension.es.richtoscan�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.richtoscan-v1.4.56.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.richtoscan.png"1.4(821.4.56B3��ߨ��ף
RichtoScanes"https://r1.richtoon.top
�
SapphireScan-eu.kanade.tachiyomi.extension.es.sapphirescan�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.sapphirescan-v1.4.53.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.sapphirescan.png"1.4(521.4.53B:����|SapphireScanes"https://www.sapphirescan.com
�
Shadow Manga,eu.kanade.tachiyomi.extension.es.shadowmanga�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.shadowmanga-v1.4.3.apkuhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.shadowmanga.png"1.4(21.4.38B4����΋��NShadow Mangaes"https://shademanga.com
�
	SkyMangas*eu.kanade.tachiyomi.extension.es.skymangas�
fhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.skymangas-v1.4.33.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.skymangas.png"1.4(!21.4.33B0���䅿��x	SkyMangases"https://skymangas.com
�

Spicy Scan*eu.kanade.tachiyomi.extension.es.spicyscan�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.spicyscan-v1.4.3.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.spicyscan.png"1.4(21.4.38B3��������$
Spicy Scanes"https://spicyseries.com
�
Stick Horse+eu.kanade.tachiyomi.extension.es.stickhorse�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.stickhorse-v1.4.51.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.stickhorse.png"1.4(321.4.518B2��܃����rStick Horsees"https://stickhorse.cl
�
	Submanhwa*eu.kanade.tachiyomi.extension.es.submanhwa�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.submanhwa-v1.4.8.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.submanhwa.png"1.4(21.4.88B0�͋��˛�	Submanhwaes"https://submanhwa.com
�
Sword Of Oblivion0eu.kanade.tachiyomi.extension.es.swordofoblivion�
lhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.swordofoblivion-v1.4.51.apkyhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.swordofoblivion.png"1.4(321.4.51B>��������TSword Of Obliviones"https://swordofoblivion.com
�
Taurus Fansub-eu.kanade.tachiyomi.extension.es.taurusfansub�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.taurusfansub-v1.4.60.apkvhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.taurusfansub.png"1.4(<21.4.60B7���ؒ���GTaurus Fansubes"https://lectortaurus.com
�
Temple Scan.eu.kanade.tachiyomi.extension.es.templescanesp�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.templescanesp-v1.4.62.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.templescanesp.png"1.4(>21.4.628B8��̻���/Temple Scanes"https://aedexnox.akan01.com
�

Falco Scan+eu.kanade.tachiyomi.extension.es.tenkaiscan�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.tenkaiscan-v1.4.39.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tenkaiscan.png"1.4('21.4.398B1��������S
Falco Scanes"https://falcoscan.net
�
Toon-es'eu.kanade.tachiyomi.extension.es.toones�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.toones-v1.4.51.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.toones.png"1.4(321.4.518B,�����EToon-eses"https://toon-es.com
�
TopComicPorno.eu.kanade.tachiyomi.extension.es.topcomicporno�
jhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.topcomicporno-v1.4.51.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.topcomicporno.png"1.4(321.4.518B8��؄��Ț]TopComicPornoes"https://topcomicporno.com
�
TopComicPorno.net1eu.kanade.tachiyomi.extension.es.topcomicpornonet�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.topcomicpornonet-v1.4.51.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.topcomicpornonet.png"1.4(321.4.518B<��������^TopComicPorno.netes"https://topcomicporno.net
�
Traducciones Moonlight6eu.kanade.tachiyomi.extension.es.traduccionesmoonlight�
rhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.traduccionesmoonlight-v1.4.47.apkhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.traduccionesmoonlight.png"1.4(/21.4.478BI��ڡ݆��<Traducciones Moonlightes"!https://traduccionesmoonlight.com
�
	ManhwasMe.eu.kanade.tachiyomi.extension.es.tumanhwasclub�
ihttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.tumanhwasclub-v1.4.3.apkwhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.tumanhwasclub.png"1.4(21.4.38B-������ߊo	ManhwasMees"https://manhwas.me
�
Uchuujin Projects1eu.kanade.tachiyomi.extension.es.uchuujinprojects�
mhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.uchuujinprojects-v1.4.34.apkzhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.uchuujinprojects.png"1.4("21.4.348B=�����ѐ�6Uchuujin Projectses"https://uchuujinmangas.com
�
VCPVMP'eu.kanade.tachiyomi.extension.es.vcpvmp�
chttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.vcpvmp-v1.4.12.apkphttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.vcpvmp.png"1.4(21.4.128B/���ժ���uVCPes"https://vercomicsporno.comB/������DVMPes"https://vermangasporno.com
�
Ver Manhwas+eu.kanade.tachiyomi.extension.es.vermanhwas�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.vermanhwas-v1.4.53.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.vermanhwas.png"1.4(521.4.538B2�Ì�����9Ver Manhwases"https://vermanhwa.com
�
Yupmanga)eu.kanade.tachiyomi.extension.es.yupmanga�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.yupmanga-v1.4.16.apkrhttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.yupmanga.png"1.4(21.4.168B2ĳ߇�ݐ�=Yupmangaes"https://www.yupmanga.com
�
Yuri-Online+eu.kanade.tachiyomi.extension.es.yurionline�
ghttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.yurionline-v1.4.51.apkthttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.yurionline.png"1.4(321.4.518B4��������/Yuri-Onlinees"https://yuri-online.com
�
Zonatmo.to (unoriginal)*eu.kanade.tachiyomi.extension.es.zonatmoto�
ehttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/apk/tachiyomi-es.zonatmoto-v1.4.2.apkshttps://raw.githubusercontent.com/vtorres-t/ext/refs/heads/repo/icon/eu.kanade.tachiyomi.extension.es.zonatmoto.png"1.4(21.4.28B;��Ɖ���Zonatmo.to (unoriginal)es"https://zonatmo.to